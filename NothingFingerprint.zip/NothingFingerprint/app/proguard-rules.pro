# Явно зберігаємо системні компоненти, які Android запускає через Manifest.
-keep class com.nothing.glyphfp.MainActivity { *; }
-keep class com.nothing.glyphfp.service.FingerprintOverlayService { *; }
