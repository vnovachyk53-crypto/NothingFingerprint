package com.nothing.glyphfp

import com.nothing.glyphfp.model.DwellFilter
import com.nothing.glyphfp.model.OverlayPromptDetector
import com.nothing.glyphfp.model.RecentEvent
import com.nothing.glyphfp.model.WindowFacts
import com.nothing.glyphfp.model.WindowKind
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OverlayPromptDetectorTest {

    private val w = 1080
    private val h = 2400

    private val app = WindowFacts(
        packageName = "ua.olx.app", kind = WindowKind.APPLICATION, title = "OLX",
        paneTitle = null, layer = 1, focused = false, active = false, width = w, height = h
    )

    private fun system(
        title: String? = null,
        pane: String? = null,
        layer: Int = 5,
        focused: Boolean = false,
        active: Boolean = false,
        width: Int = w,
        height: Int = h,
        pkg: String = "com.android.systemui",
        ids: Set<String> = emptySet()
    ) = WindowFacts(pkg, WindowKind.SYSTEM, title, pane, layer, focused, active, width, height, ids)

    private fun detect(vararg windows: WindowFacts, recentShade: Boolean = false) =
        OverlayPromptDetector.detect(windows.toList(), w, h, "com.nothing.glyphfp", recentShade)

    @Test
    fun biometricPromptWithBlankTitleOverBankingApp() {
        assertTrue(detect(app, system(title = " ")))
    }

    @Test
    fun hiddenTreeStillDetectedThroughDialogWindow() {
        // Дерево вузлів недоступне: ids порожні, але діалог не на всю висоту має фокус.
        assertTrue(detect(app, system(title = null, focused = true, height = 1500)))
        assertTrue(detect(app, system(title = null, active = true, height = 1500, pkg = "com.android.settings")))
    }

    @Test
    fun directEvidenceWinsEvenRightAfterShade() {
        assertTrue(detect(app, system(title = "BiometricPrompt"), recentShade = true))
        assertTrue(detect(app, system(ids = setOf("biometric_icon")), recentShade = true))
    }

    @Test
    fun ordinaryAppWithBarsIsNotAPrompt() {
        val statusBar = system(title = "Status bar", height = 120)
        val navBar = system(title = null, layer = 4, height = 90)
        assertFalse(detect(app, statusBar, navBar))
        assertFalse(detect(app))
    }

    @Test
    fun shadeIsNotAPrompt() {
        assertFalse(detect(app, system(title = "Notification shade.", focused = true)))
        assertFalse(detect(app, system(pane = "Quick settings", active = true, height = 1500)))
        assertFalse(detect(app, system(title = " ", ids = setOf("quick_settings_panel"))))
        assertFalse(detect(app, system(title = "Шторка сповіщень", focused = true)))
    }

    @Test
    fun fullHeightUnknownWindowIsTreatedAsShade() {
        assertFalse(detect(app, system(title = null, focused = true)))
    }

    @Test
    fun dialogsRightAfterShadeAreIgnored() {
        assertFalse(detect(app, system(title = null, focused = true, height = 1500), recentShade = true))
        assertFalse(detect(app, system(title = " "), recentShade = true))
    }

    @Test
    fun volumeAndPowerMenuAreIgnored() {
        assertFalse(detect(app, system(title = "Volume", focused = true, width = 200, height = 900)))
        assertFalse(detect(app, system(title = "Power menu", focused = true, height = 1500)))
    }

    @Test
    fun thirdPartyOverlaysAndWindowsBelowTheAppAreIgnored() {
        assertFalse(detect(app, system(title = " ", pkg = "com.some.floating.widget")))
        assertFalse(detect(app, system(title = " ", layer = 0)))
    }

    @Test
    fun windowWithoutRootNeedsBlankTitle() {
        assertTrue(detect(app, system(title = " ", pkg = "")))
        assertFalse(detect(app, system(title = null, focused = true, height = 1500, pkg = "")))
    }

    @Test
    fun noThirdPartyAppMeansNoPrompt() {
        val own = app.copy(packageName = "com.nothing.glyphfp")
        assertFalse(detect(own, system(title = " ")))
    }

    @Test
    fun dwellFilterNeedsContinuousSignal() {
        val filter = DwellFilter(1_000)
        assertFalse(filter.update(true, 100))
        assertFalse(filter.update(true, 900))
        assertTrue(filter.update(true, 1_100))
        assertFalse(filter.update(false, 1_200))
        assertFalse(filter.update(true, 1_300))
        filter.reset()
        assertFalse(filter.update(true, 5_000))
    }

    @Test
    fun recentEventExpiresAndClears() {
        val event = RecentEvent(1_500)
        assertFalse(event.isRecent(100))
        event.mark(1_000)
        assertTrue(event.isRecent(2_000))
        assertFalse(event.isRecent(2_600))
        event.mark(3_000)
        event.clear()
        assertFalse(event.isRecent(3_100))
    }
}
