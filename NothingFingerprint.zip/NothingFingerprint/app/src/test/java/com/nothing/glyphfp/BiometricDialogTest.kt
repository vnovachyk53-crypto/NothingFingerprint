package com.nothing.glyphfp

import com.nothing.glyphfp.model.BiometricDialog
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BiometricDialogTest {
    private val w = 1080
    private val h = 2400

    private fun prompt(cls: String?, width: Int = 0, height: Int = 0) =
        BiometricDialog.isPrompt(cls, width, height, w, h)

    @Test
    fun authContainerIsPromptEvenFullScreen() {
        assertTrue(prompt("com.android.systemui.biometrics.ui.AuthContainerView", w, h))
        assertTrue(prompt("com.android.systemui.biometrics.AuthContainerView"))
    }

    @Test
    fun dialogSizedWindowIsPrompt() {
        assertTrue(prompt("android.app.Dialog", w, 1500))
        assertTrue(prompt(null, 900, 1200))
    }

    @Test
    fun fullHeightWindowIsShade() {
        assertFalse(prompt("android.view.ViewGroup", w, h))
        assertFalse(prompt("com.android.systemui.shade.NotificationShadeWindowView", w, 1500))
    }

    @Test
    fun smallOrNarrowWindowsAreNotPrompts() {
        assertFalse(prompt("android.widget.FrameLayout", w, 300))
        assertFalse(prompt("android.widget.FrameLayout", 250, 1200))
    }

    @Test
    fun unknownBoundsWithoutPromptClassIsNotPrompt() {
        assertFalse(prompt(null))
        assertFalse(prompt("android.app.Dialog"))
    }

    @Test
    fun knownSystemPanelsAreIgnored() {
        assertFalse(prompt("com.android.systemui.volume.VolumeDialog", w, 1500))
        assertFalse(prompt("com.android.systemui.globalactions.GlobalActionsDialog", w, 1500))
    }
}
