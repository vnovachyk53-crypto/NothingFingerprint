package com.nothing.glyphfp

import com.nothing.glyphfp.model.SystemUiSignatures
import com.nothing.glyphfp.model.TriggerMode
import com.nothing.glyphfp.model.TriggerPolicy
import com.nothing.glyphfp.model.TriggerState
import com.nothing.glyphfp.model.UiSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TriggerPolicyTest {

    private val off = TriggerState(watchTouch = false, showBeacon = false)
    private val on = TriggerState(watchTouch = true, showBeacon = true)

    private fun evaluate(
        interactive: Boolean = true,
        locked: Boolean = false,
        mode: TriggerMode = TriggerMode.BIOMETRIC_TOUCH,
        beacon: Boolean = true,
        ui: UiSnapshot = UiSnapshot()
    ) = TriggerPolicy.evaluate(interactive, locked, mode, beacon, ui)

    @Test
    fun ordinaryAppIsOff() {
        assertEquals(off, evaluate())
    }

    @Test
    fun lockscreenAndPromptAreOn() {
        assertEquals(on, evaluate(locked = true))
        assertEquals(on, evaluate(ui = UiSnapshot(biometricPrompt = true)))
    }

    @Test
    fun lockscreenIgnoresShadeAndCredentialFlags() {
        // Екран блокування не фільтрується: детектор дотику активний, маячок ховається.
        val hidden = TriggerState(watchTouch = true, showBeacon = false)
        assertEquals(hidden, evaluate(locked = true, ui = UiSnapshot(shadeExpanded = true)))
        assertEquals(hidden, evaluate(locked = true, ui = UiSnapshot(credentialInput = true)))
    }

    @Test
    fun lockscreenWorksWhenStaleSnapshotLooksLikeAnApp() {
        // Без підтвердженого перекриття (appOverLockscreen=false) блокування завжди активне.
        assertEquals(on, evaluate(locked = true, ui = UiSnapshot()))
        assertEquals(on, evaluate(interactive = true, locked = true, ui = UiSnapshot(biometricPrompt = true)))
    }

    @Test
    fun confirmedOccludingAppTurnsLockscreenOff() {
        assertEquals(off, evaluate(locked = true, ui = UiSnapshot(appOverLockscreen = true)))
    }

    @Test
    fun promptIsBlockedByShadeAndCredentialButOnlyWhenUnlocked() {
        assertEquals(off, evaluate(ui = UiSnapshot(biometricPrompt = true, shadeExpanded = true)))
        assertEquals(off, evaluate(ui = UiSnapshot(biometricPrompt = true, credentialInput = true)))
    }

    @Test
    fun promptOverOccludedLockscreenIsOn() {
        val ui = UiSnapshot(biometricPrompt = true, appOverLockscreen = true)
        assertEquals(on, evaluate(locked = true, ui = ui))
    }

    @Test
    fun screenOffArmsOnlyLockedTouchDetector() {
        assertEquals(
            TriggerState(watchTouch = true, showBeacon = false),
            evaluate(interactive = false, locked = true)
        )
        assertEquals(off, evaluate(interactive = false))
    }

    @Test
    fun afterUnlockModeNeverWatchesTouches() {
        assertFalse(evaluate(locked = true, mode = TriggerMode.AFTER_UNLOCK).watchTouch)
        assertTrue(evaluate(locked = true, mode = TriggerMode.AFTER_UNLOCK).showBeacon)
    }

    @Test
    fun beaconToggleIsRespected() {
        assertFalse(evaluate(locked = true, beacon = false).showBeacon)
    }

    @Test
    fun recognisesPromptWindows() {
        assertTrue(analyze("biometric_icon", "title").biometricPrompt)
        assertTrue(analyze("panel", "button_negative").biometricPrompt)
        assertTrue(
            SystemUiSignatures.analyze("BiometricPrompt", emptySet(), emptyList()).biometricPrompt
        )
        assertTrue(
            SystemUiSignatures.analyze(null, emptySet(), listOf("Сканер відбитків пальців"))
                .biometricPrompt
        )
    }

    @Test
    fun ordinarySystemUiWindowsAreNotPrompts() {
        assertEquals(UiSnapshot(), analyze("clock", "battery", "wifi_combo"))
        assertEquals(UiSnapshot(), analyze("panel"))
        assertEquals(
            UiSnapshot(),
            SystemUiSignatures.analyze("Мрія", setOf("volume_dialog"), listOf("Unlock"))
        )
    }

    @Test
    fun recognisesShadeAndCredentials() {
        val shade = analyze("quick_settings_panel", "biometric_icon")
        assertTrue(shade.shadeExpanded)
        assertFalse(shade.biometricPrompt)
        assertTrue(analyze("auth_container", "lockPassword").credentialInput)
        assertTrue(analyze("keyguard_pin_view").credentialInput)
    }

    @Test
    fun stripsViewIdPackage() {
        assertEquals("panel", SystemUiSignatures.entryName("com.android.systemui:id/panel"))
    }

    private fun analyze(vararg ids: String) =
        SystemUiSignatures.analyze(null, ids.toSet(), emptyList())
}
