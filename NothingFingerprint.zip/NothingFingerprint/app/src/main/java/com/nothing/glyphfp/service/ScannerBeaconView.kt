package com.nothing.glyphfp.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private const val DOT_COUNT = 24
private const val PERIOD_MS = 1_800L
private const val FRAME_MS = 33L

/**
 * Ледь помітне пульсуюче точкове кільце. Малює лише по краю зони, центр лишається прозорим,
 * щоб не закривати оптичний сканер. Перемальовується приблизно 30 разів на секунду.
 */
class ScannerBeaconView(context: Context, private val ringRadiusPx: Float) : View(context) {

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentColor = Color.rgb(215, 25, 33)
    private val unitX = FloatArray(DOT_COUNT) { cos(2.0 * PI * it / DOT_COUNT).toFloat() }
    private val unitY = FloatArray(DOT_COUNT) { sin(2.0 * PI * it / DOT_COUNT).toFloat() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val phase = (SystemClock.uptimeMillis() % PERIOD_MS).toFloat() / PERIOD_MS
        val wave = (sin(phase * 2f * PI.toFloat()) + 1f) / 2f
        val ring = ringRadiusPx + wave * 3f * density
        val centerX = width / 2f
        val centerY = height / 2f

        for (index in 0 until DOT_COUNT) {
            paint.color = if (index % 6 == 0) accentColor else Color.WHITE
            // alpha задається після color, бо color її перезаписує.
            paint.alpha = (45f + 75f * wave).toInt()
            canvas.drawCircle(
                centerX + unitX[index] * ring,
                centerY + unitY[index] * ring,
                1.6f * density,
                paint
            )
        }
        postInvalidateDelayed(FRAME_MS)
    }
}
