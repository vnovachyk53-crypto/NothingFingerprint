package com.nothing.glyphfp.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nothing.glyphfp.model.AnimationPreset
import com.nothing.glyphfp.model.CustomMediaType
import com.nothing.glyphfp.model.DEFAULT_SCALE
import com.nothing.glyphfp.model.DEFAULT_SCANNER_RADIUS_DP
import com.nothing.glyphfp.model.ScannerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "nothing_fp_calibration"
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val PRESET_ID = stringPreferencesKey("preset_id")
        val CENTER_X = floatPreferencesKey("center_x_norm")
        val CENTER_Y = floatPreferencesKey("center_y_norm")
        val SCALE = floatPreferencesKey("anim_scale")
        val SPEED = floatPreferencesKey("anim_speed")
        val SCANNER_RADIUS = floatPreferencesKey("scanner_radius_dp")
        val BEACON = booleanPreferencesKey("beacon_enabled")
        val HAPTIC = booleanPreferencesKey("haptic_enabled")
        val CUSTOM_URI = stringPreferencesKey("custom_uri")
        val CUSTOM_NAME = stringPreferencesKey("custom_file_name")
        val CUSTOM_TYPE = stringPreferencesKey("custom_media_type")
    }

    val configFlow: Flow<ScannerConfig> = context.dataStore.data.catch { error ->
        // Пошкоджений або недоступний файл налаштувань не повинен валити застосунок.
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { prefs ->
        val mediaType = runCatching {
            CustomMediaType.valueOf(prefs[Keys.CUSTOM_TYPE] ?: CustomMediaType.NONE.name)
        }.getOrDefault(CustomMediaType.NONE)

        ScannerConfig(
            preset = AnimationPreset.fromId(prefs[Keys.PRESET_ID]),
            centerXNormalized = prefs[Keys.CENTER_X] ?: 0.50f,
            centerYNormalized = prefs[Keys.CENTER_Y] ?: 0.875f,
            scale = prefs[Keys.SCALE] ?: DEFAULT_SCALE,
            speed = prefs[Keys.SPEED] ?: 1.0f,
            customUriString = prefs[Keys.CUSTOM_URI],
            customFileName = prefs[Keys.CUSTOM_NAME],
            customMediaType = mediaType,
            scannerRadiusDp = prefs[Keys.SCANNER_RADIUS] ?: DEFAULT_SCANNER_RADIUS_DP,
            beaconEnabled = prefs[Keys.BEACON] ?: true,
            hapticEnabled = prefs[Keys.HAPTIC] ?: true
        )
    }

    suspend fun selectPreset(preset: AnimationPreset) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PRESET_ID] = preset.id
        }
    }

    suspend fun updateCenterX(value: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CENTER_X] = value.coerceIn(0.05f, 0.95f)
        }
    }

    suspend fun updateCenterY(value: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CENTER_Y] = value.coerceIn(0.45f, 0.98f)
        }
    }

    suspend fun updateScale(value: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SCALE] = value.coerceIn(0.5f, 2.0f)
        }
    }

    suspend fun updateSpeed(value: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SPEED] = value.coerceIn(0.4f, 2.5f)
        }
    }

    suspend fun updateScannerRadius(value: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SCANNER_RADIUS] = value.coerceIn(24f, 70f)
        }
    }

    suspend fun setBeaconEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BEACON] = enabled
        }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.HAPTIC] = enabled
        }
    }

    suspend fun resetCalibration() {
        context.dataStore.edit { prefs ->
            prefs[Keys.CENTER_X] = 0.50f
            prefs[Keys.CENTER_Y] = 0.875f
            prefs[Keys.SCALE] = DEFAULT_SCALE
            prefs[Keys.SPEED] = 1.0f
            prefs[Keys.SCANNER_RADIUS] = DEFAULT_SCANNER_RADIUS_DP
        }
    }

    suspend fun saveCustomMedia(uri: Uri) {
        val fileName = resolveDisplayName(uri) ?: "custom_animation"
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        val lowerName = fileName.lowercase()

        val detectedType = when {
            lowerName.endsWith(".json") || mime.contains("json") -> CustomMediaType.LOTTIE_JSON
            lowerName.endsWith(".gif") || mime.contains("gif") -> CustomMediaType.ANIMATED_GIF
            lowerName.endsWith(".webm") || mime.contains("webm") -> CustomMediaType.TRANSPARENT_WEBM
            else -> throw IllegalArgumentException(
                "Непідтримуваний формат. Оберіть файл .json, .gif або .webm."
            )
        }

        context.dataStore.edit { prefs ->
            prefs[Keys.CUSTOM_URI] = uri.toString()
            prefs[Keys.CUSTOM_NAME] = fileName
            prefs[Keys.CUSTOM_TYPE] = detectedType.name
            prefs[Keys.PRESET_ID] = AnimationPreset.CUSTOM_FILE.id
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
        }.getOrNull()
    }
}
