package com.nothing.glyphfp.model

/**
 * Чиста логіка без Android API: чи є вікно SystemUI діалогом біометрії, а не шторкою чи
 * іншою системною панеллю. Викликається лише на подію TYPE_WINDOW_STATE_CHANGED.
 */
object BiometricDialog {

    // Клас вікна біометрії в AOSP: com.android.systemui.biometrics.AuthContainerView.
    private val promptClassTokens = listOf("authcontainer", "biometric", "authdialog")

    private val otherPanelTokens = listOf(
        "notificationshade", "shade", "statusbar", "volume", "globalactions",
        "screenshot", "keyguard", "headsup", "quicksettings"
    )

    private const val MIN_WIDTH_RATIO = 0.5f
    private const val MIN_HEIGHT_RATIO = 0.25f
    private const val FULL_HEIGHT_RATIO = 0.9f

    /**
     * @param className клас, який передала подія (може бути null).
     * @param width ширина вікна в пікселях або 0, якщо межі невідомі.
     * @param height висота вікна в пікселях або 0, якщо межі невідомі.
     */
    fun isPrompt(
        className: String?,
        width: Int,
        height: Int,
        displayWidth: Int,
        displayHeight: Int
    ): Boolean {
        val name = className?.lowercase().orEmpty()
        // Пряма ознака: вікно BiometricPrompt, навіть якщо воно на весь екран.
        if (promptClassTokens.any { name.contains(it) }) return true
        if (otherPanelTokens.any { name.contains(it) }) return false

        if (width <= 0 || height <= 0) return false
        // Діалог, а не шторка: вікно не на всю висоту екрана.
        return width >= displayWidth * MIN_WIDTH_RATIO &&
                height >= displayHeight * MIN_HEIGHT_RATIO &&
                height < displayHeight * FULL_HEIGHT_RATIO
    }
}
