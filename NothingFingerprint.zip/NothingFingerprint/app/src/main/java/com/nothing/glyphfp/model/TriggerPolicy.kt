package com.nothing.glyphfp.model

// Чиста логіка без Android API: коли можна запускати анімацію і що означають вікна SystemUI.

/** Що зараз видно на екрані за даними AccessibilityService. */
data class UiSnapshot(
    val biometricPrompt: Boolean = false,
    val shadeExpanded: Boolean = false,
    val credentialInput: Boolean = false,
    val appOverLockscreen: Boolean = false
) {
    fun merge(other: UiSnapshot) = UiSnapshot(
        biometricPrompt = biometricPrompt || other.biometricPrompt,
        shadeExpanded = shadeExpanded || other.shadeExpanded,
        credentialInput = credentialInput || other.credentialInput,
        appOverLockscreen = appOverLockscreen || other.appOverLockscreen
    )
}

data class TriggerState(
    val watchTouch: Boolean,
    val showBeacon: Boolean
)

object TriggerPolicy {
    fun evaluate(
        interactive: Boolean,
        keyguardLocked: Boolean,
        mode: TriggerMode,
        beaconEnabled: Boolean,
        ui: UiSnapshot
    ): TriggerState {
        // Шторка та введення PIN/пароля/ключа вимикають усе.
        val blocked = ui.shadeExpanded || ui.credentialInput
        val onLockscreen = keyguardLocked && !ui.appOverLockscreen
        val onPrompt = interactive && ui.biometricPrompt
        val eligible = !blocked && (onLockscreen || onPrompt)

        return TriggerState(
            watchTouch = eligible && mode == TriggerMode.BIOMETRIC_TOUCH,
            showBeacon = eligible && interactive && beaconEnabled
        )
    }
}

/**
 * Ознаки вікон SystemUI. Ідентифікатори взято з AOSP; на прошивці виробника вони можуть
 * відрізнятися, тому застосунок показує знайдені ID в діагностиці.
 */
object SystemUiSignatures {
    private val promptIds = setOf(
        "biometric_icon",
        "biometric_icon_overlay",
        "biometric_scrollview",
        "biometric_prompt_constraint_layout",
        "auth_container",
        "button_use_credential"
    )

    // Загальні назви: вважаємо вікно запитом біометрії лише разом із "panel".
    private val promptPanelCompanions = setOf("button_negative", "button_confirm", "indicator")

    private val shadeIds = setOf("quick_settings_panel", "quick_qs_panel", "qs_panel")

    private val credentialIds = setOf(
        "keyguard_pin_view",
        "keyguard_password_view",
        "keyguard_pattern_view",
        "keyguard_sim_pin_view",
        "keyguard_sim_puk_view",
        "lockPatternView",
        "lockPattern",
        "lockPassword",
        "pinEntry",
        "passwordEntry"
    )

    private val sensorPhrases = listOf(
        "fingerprint sensor",
        "сканер відбитк",
        "сканера відбитк",
        "датчик відбитк",
        "датчика відбитк",
        "сканер отпечатк",
        "датчик отпечатк"
    )

    fun entryName(viewId: String): String = viewId.substringAfter(":id/")

    fun analyze(windowTitle: String?, ids: Set<String>, descriptions: List<String>): UiSnapshot {
        val shade = ids.any { it in shadeIds }
        val credential = ids.any { it in credentialIds }
        val sensorDescribed = descriptions.any { description ->
            val value = description.lowercase()
            sensorPhrases.any { value.contains(it) }
        }
        val prompt = !shade && (
                windowTitle == "BiometricPrompt" ||
                        ids.any { it in promptIds } ||
                        ("panel" in ids && ids.any { it in promptPanelCompanions }) ||
                        sensorDescribed
                )
        return UiSnapshot(
            biometricPrompt = prompt,
            shadeExpanded = shade,
            credentialInput = credential
        )
    }

    /** Чи варто показати ID нерозпізнаного вікна в діагностиці. */
    fun looksRelated(ids: Set<String>): Boolean = ids.any { id ->
        val value = id.lowercase()
        value.contains("biometric") || value.contains("udfps") ||
                value.contains("auth") || value.contains("credential")
    }
}
