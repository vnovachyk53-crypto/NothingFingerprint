package com.nothing.glyphfp.model

// Чиста логіка без Android API: коли можна запускати анімацію і що означають вікна SystemUI.

/** Що зараз видно на екрані за даними AccessibilityService. */
data class UiSnapshot(
    val biometricPrompt: Boolean = false,
    val shadeExpanded: Boolean = false,
    val credentialInput: Boolean = false,
    val appOverLockscreen: Boolean = false
) {
    fun merge(other: UiSnapshot) = UiSnapshot(
        biometricPrompt = biometricPrompt || other.biometricPrompt,
        shadeExpanded = shadeExpanded || other.shadeExpanded,
        credentialInput = credentialInput || other.credentialInput,
        appOverLockscreen = appOverLockscreen || other.appOverLockscreen
    )
}

data class TriggerState(
    val watchTouch: Boolean,
    val showBeacon: Boolean
)

object TriggerPolicy {
    /**
     * Екран блокування (keyguardLocked) ніколи не фільтрується за вікнами SystemUI, шторкою чи
     * введенням PIN: детектор дотику на ньому активний завжди. Єдиний виняток — застосунок,
     * який стабільно перекриває блокування (камера, дзвінок); сервіс передає
     * [UiSnapshot.appOverLockscreen] лише після короткого підтвердження, щоб застарілий
     * "активний" застосунок після виходу з нього не вимикав детектор.
     *
     * Шторка й введення PIN/пароля діють лише на запит біометрії (екран розблокований) і на маячок.
     */
    fun evaluate(
        interactive: Boolean,
        keyguardLocked: Boolean,
        mode: TriggerMode,
        beaconEnabled: Boolean,
        ui: UiSnapshot
    ): TriggerState {
        val blocked = ui.shadeExpanded || ui.credentialInput
        val onLockscreen = keyguardLocked && !ui.appOverLockscreen
        val onPrompt = interactive && ui.biometricPrompt && !blocked

        val watchTouch = (onLockscreen || onPrompt) && mode == TriggerMode.BIOMETRIC_TOUCH
        val showBeacon = (onLockscreen || onPrompt) && interactive && !blocked && beaconEnabled

        return TriggerState(watchTouch = watchTouch, showBeacon = showBeacon)
    }
}

/** Вікно за даними AccessibilityWindowInfo; дерево вузлів може бути прихованим (Android 17). */
enum class WindowKind { APPLICATION, SYSTEM, OTHER }

data class WindowFacts(
    /** Порожній рядок, якщо система не віддала root вікна. */
    val packageName: String,
    val kind: WindowKind,
    val title: String?,
    val paneTitle: String?,
    val layer: Int,
    val focused: Boolean,
    val active: Boolean,
    val width: Int,
    val height: Int,
    val ids: Set<String> = emptySet(),
    val descriptions: List<String> = emptyList()
)

/**
 * Широке розпізнавання запиту біометрії, яке не залежить від текстових вузлів: системний діалог
 * (TYPE_SYSTEM; TYPE_APPLICATION_OVERLAY в API доступності теж виглядає як TYPE_SYSTEM) від
 * SystemUI або Settings, що з'явився поверх стороннього застосунку. Шторка, гучність, меню
 * живлення та інші системні панелі відсіюються.
 */
object OverlayPromptDetector {
    private val systemPackages = setOf("com.android.systemui", "com.android.settings")

    // Назви (англ./укр./рос.) вікон, які точно не є запитом біометрії.
    private val nonPromptTitles = listOf(
        "notification shade", "notification panel", "quick settings", "shade",
        "шторк", "швидкі налаштування", "панель сповіщень", "сповіщен",
        "шторка", "панель уведомлений", "уведомлен", "быстрые настройки",
        "power menu", "global actions", "globalactions", "screenshot", "volume",
        "живлення", "гучність", "питания", "громкость", "скриншот", "знімок екрана",
        "status bar", "navigation bar", "lock screen", "екран блокування", "экран блокировки"
    )

    private const val MIN_WIDTH_RATIO = 0.5f
    private const val MIN_HEIGHT_RATIO = 0.25f
    private const val FULL_HEIGHT_RATIO = 0.9f

    fun isShadeLike(w: WindowFacts): Boolean {
        val named = listOf(w.title, w.paneTitle).any { text ->
            val value = text?.lowercase().orEmpty()
            value.isNotBlank() && nonPromptTitles.any { value.contains(it) }
        }
        return named || w.ids.any { it in SystemUiSignatures.shadeIds }
    }

    fun isSystemCandidate(w: WindowFacts): Boolean =
        w.kind == WindowKind.SYSTEM && (w.packageName.isEmpty() || w.packageName in systemPackages)

    fun isThirdPartyApp(w: WindowFacts, ownPackage: String): Boolean =
        w.kind == WindowKind.APPLICATION &&
                w.packageName.isNotEmpty() &&
                w.packageName !in systemPackages &&
                w.packageName != ownPackage

    /**
     * @param recentShade шторка була видна щойно: діалоги, що відкриваються з неї, запитом
     *   біометрії не вважаються, якщо немає прямих ознак.
     */
    fun detect(
        windows: List<WindowFacts>,
        displayWidth: Int,
        displayHeight: Int,
        ownPackage: String,
        recentShade: Boolean
    ): Boolean {
        val appLayer = windows.filter { isThirdPartyApp(it, ownPackage) }
            .maxOfOrNull { it.layer } ?: return false

        return windows.any { w ->
            if (!isSystemCandidate(w) || w.layer <= appLayer) return@any false
            if (w.width < displayWidth * MIN_WIDTH_RATIO) return@any false
            if (w.height < displayHeight * MIN_HEIGHT_RATIO) return@any false
            if (isShadeLike(w)) return@any false

            val direct = SystemUiSignatures.analyze(w.title, w.ids, w.descriptions).biometricPrompt
            // Вікно BiometricPrompt має порожню accessibilityTitle (" "), а не "BiometricPrompt".
            val blankTitle = w.title?.isBlank() == true
            // Вікно на всю висоту без прямих ознак вважається шторкою; фокус без root не враховується.
            val dialogSized = w.height < displayHeight * FULL_HEIGHT_RATIO
            val hasInput = dialogSized && w.packageName.isNotEmpty() && (w.focused || w.active)
            direct || (!recentShade && (blankTitle || hasInput))
        }
    }
}

/** Сигнал, який вважається істинним, лише якщо тримається [holdMs] без перерви. */
class DwellFilter(private val holdMs: Long) {
    private var since = 0L

    fun update(active: Boolean, nowMs: Long): Boolean {
        if (!active) {
            since = 0L
            return false
        }
        if (since == 0L) since = nowMs
        return nowMs - since >= holdMs
    }

    fun reset() {
        since = 0L
    }
}

/** Пам'ятає останній момент події й каже, чи вона була менше ніж [holdMs] тому. */
class RecentEvent(private val holdMs: Long) {
    private var last = 0L

    fun mark(nowMs: Long) {
        last = nowMs
    }

    fun isRecent(nowMs: Long): Boolean = last != 0L && nowMs - last < holdMs

    fun clear() {
        last = 0L
    }
}

/**
 * Ознаки вікон SystemUI. Ідентифікатори взято з AOSP; на прошивці виробника вони можуть
 * відрізнятися, тому застосунок показує знайдені ID в діагностиці.
 */
object SystemUiSignatures {
    private val promptIds = setOf(
        "biometric_icon",
        "biometric_icon_overlay",
        "biometric_scrollview",
        "biometric_prompt_constraint_layout",
        "auth_container",
        "button_use_credential"
    )

    // Загальні назви: вважаємо вікно запитом біометрії лише разом із "panel".
    private val promptPanelCompanions = setOf("button_negative", "button_confirm", "indicator")

    // Лише ID, яких немає на самому екрані блокування (notification_panel там є завжди).
    val shadeIds = setOf("quick_settings_panel", "quick_qs_panel", "qs_panel")

    private val credentialIds = setOf(
        "keyguard_pin_view",
        "keyguard_password_view",
        "keyguard_pattern_view",
        "keyguard_sim_pin_view",
        "keyguard_sim_puk_view",
        "lockPatternView",
        "lockPattern",
        "lockPassword",
        "pinEntry",
        "passwordEntry"
    )

    private val sensorPhrases = listOf(
        "fingerprint sensor",
        "сканер відбитк",
        "сканера відбитк",
        "датчик відбитк",
        "датчика відбитк",
        "сканер отпечатк",
        "датчик отпечатк"
    )

    fun entryName(viewId: String): String = viewId.substringAfter(":id/")

    fun analyze(windowTitle: String?, ids: Set<String>, descriptions: List<String>): UiSnapshot {
        val shade = ids.any { it in shadeIds }
        val credential = ids.any { it in credentialIds }
        val sensorDescribed = descriptions.any { description ->
            val value = description.lowercase()
            sensorPhrases.any { value.contains(it) }
        }
        val prompt = !shade && (
                windowTitle == "BiometricPrompt" ||
                        ids.any { it in promptIds } ||
                        ("panel" in ids && ids.any { it in promptPanelCompanions }) ||
                        sensorDescribed
                )
        return UiSnapshot(
            biometricPrompt = prompt,
            shadeExpanded = shade,
            credentialInput = credential
        )
    }

    /** Чи варто показати ID нерозпізнаного вікна в діагностиці. */
    fun looksRelated(ids: Set<String>): Boolean = ids.any { id ->
        val value = id.lowercase()
        value.contains("biometric") || value.contains("udfps") ||
                value.contains("auth") || value.contains("credential")
    }
}
