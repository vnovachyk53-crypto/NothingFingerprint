package com.nothing.glyphfp.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.nothing.glyphfp.model.OverlayPromptDetector
import com.nothing.glyphfp.model.SystemUiSignatures
import com.nothing.glyphfp.model.UiSnapshot
import com.nothing.glyphfp.model.WindowFacts
import com.nothing.glyphfp.model.WindowKind

private const val SYSTEM_UI_PACKAGE = "com.android.systemui"
private const val SETTINGS_PACKAGE = "com.android.settings"
private const val MAX_NODES_PER_WINDOW = 220
private const val MAX_CHILDREN = 30

/** Читає видимі вікна. Виклики повільні, тому [scan] запускається не в головному потоці. */
class SystemUiScanner(private val service: AccessibilityService) {

    data class Result(
        val ui: UiSnapshot,
        /** ID схожого на біометрію, але нерозпізнаного вікна; порожньо, якщо такого немає. */
        val unknownIds: String,
        /** Чи розпізнано запит біометрії лише за ознаками вікна, без вузлів. */
        val promptByOverlay: Boolean = false
    )

    private class WindowContent(val ids: Set<String>, val descriptions: List<String>)

    /**
     * @param keyguardLocked на заблокованому екрані широке розпізнавання не потрібне.
     * @param recentShade шторка була видна щойно (див. [OverlayPromptDetector.detect]).
     */
    fun scan(keyguardLocked: Boolean, recentShade: Boolean): Result {
        var ui = UiSnapshot()
        var unknownIds = ""
        val windows = runCatching { service.windows }.getOrNull() ?: return Result(ui, unknownIds)
        val facts = ArrayList<WindowFacts>(windows.size)
        val bounds = Rect()

        for (window in windows) {
            // Android 17 може не віддавати root: вікно все одно враховується за типом і межами.
            val root = runCatching { window.root }.getOrNull()
            val packageName = root?.packageName?.toString().orEmpty()
            val kind = when (window.type) {
                AccessibilityWindowInfo.TYPE_APPLICATION -> WindowKind.APPLICATION
                // TYPE_APPLICATION_OVERLAY та діалоги SystemUI в API доступності є TYPE_SYSTEM.
                AccessibilityWindowInfo.TYPE_SYSTEM -> WindowKind.SYSTEM
                else -> WindowKind.OTHER
            }
            val isSystemWindow = packageName == SYSTEM_UI_PACKAGE || packageName == SETTINGS_PACKAGE ||
                    (root == null && kind == WindowKind.SYSTEM)

            var content: WindowContent? = null
            if (root != null && packageName == SYSTEM_UI_PACKAGE) {
                content = runCatching { collect(root) }.getOrNull()
                if (content != null) {
                    val found = SystemUiSignatures.analyze(
                        window.title?.toString(),
                        content.ids,
                        content.descriptions
                    )
                    ui = ui.merge(found)
                    if (!found.biometricPrompt && SystemUiSignatures.looksRelated(content.ids)) {
                        unknownIds = content.ids.sorted().take(25).joinToString(", ")
                    }
                }
            } else if (
                kind == WindowKind.APPLICATION &&
                (window.isActive || window.isFocused) &&
                packageName.isNotEmpty() &&
                packageName != service.packageName
            ) {
                ui = ui.merge(UiSnapshot(appOverLockscreen = true))
            }

            if (kind == WindowKind.APPLICATION || isSystemWindow) {
                window.getBoundsInScreen(bounds)
                facts.add(
                    WindowFacts(
                        packageName = packageName,
                        kind = kind,
                        title = window.title?.toString(),
                        paneTitle = root?.paneTitle?.toString(),
                        layer = window.layer,
                        focused = window.isFocused,
                        active = window.isActive,
                        width = bounds.width(),
                        height = bounds.height(),
                        ids = content?.ids.orEmpty(),
                        descriptions = content?.descriptions.orEmpty()
                    )
                )
            }
        }

        var byOverlay = false
        if (!keyguardLocked && !ui.biometricPrompt && !ui.shadeExpanded) {
            val metrics = service.resources.displayMetrics
            byOverlay = OverlayPromptDetector.detect(
                windows = facts,
                displayWidth = metrics.widthPixels,
                displayHeight = metrics.heightPixels,
                ownPackage = service.packageName,
                recentShade = recentShade
            )
            if (byOverlay) ui = ui.merge(UiSnapshot(biometricPrompt = true))
        }
        return Result(ui, unknownIds, byOverlay)
    }

    /** Обхід у ширину тільки видимих вузлів; список сповіщень не обходиться. */
    private fun collect(root: AccessibilityNodeInfo): WindowContent {
        val ids = mutableSetOf<String>()
        val descriptions = mutableListOf<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var inspected = 0

        while (queue.isNotEmpty() && inspected < MAX_NODES_PER_WINDOW) {
            val node = queue.removeFirst()
            inspected++
            if (!node.isVisibleToUser) continue

            val id = node.viewIdResourceName?.let { SystemUiSignatures.entryName(it) }
            if (id != null) ids.add(id)
            node.contentDescription?.let { descriptions.add(it.toString()) }

            if (id == "notification_stack_scroller") continue
            for (index in 0 until node.childCount.coerceAtMost(MAX_CHILDREN)) {
                node.getChild(index)?.let { queue.add(it) }
            }
        }
        return WindowContent(ids, descriptions)
    }
}
