package com.nothing.glyphfp.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.nothing.glyphfp.model.SystemUiSignatures
import com.nothing.glyphfp.model.UiSnapshot

private const val SYSTEM_UI_PACKAGE = "com.android.systemui"
private const val MAX_NODES_PER_WINDOW = 220
private const val MAX_CHILDREN = 30

/** Читає видимі вікна. Виклики повільні, тому [scan] запускається не в головному потоці. */
class SystemUiScanner(private val service: AccessibilityService) {

    data class Result(
        val ui: UiSnapshot,
        /** ID схожого на біометрію, але нерозпізнаного вікна; порожньо, якщо такого немає. */
        val unknownIds: String
    )

    private class WindowContent(val ids: Set<String>, val descriptions: List<String>)

    fun scan(): Result {
        var ui = UiSnapshot()
        var unknownIds = ""
        val windows = runCatching { service.windows }.getOrNull() ?: return Result(ui, unknownIds)

        for (window in windows) {
            val root = runCatching { window.root }.getOrNull() ?: continue
            val packageName = root.packageName?.toString().orEmpty()

            if (packageName == SYSTEM_UI_PACKAGE) {
                val content = runCatching { collect(root) }.getOrNull() ?: continue
                val found = SystemUiSignatures.analyze(
                    window.title?.toString(),
                    content.ids,
                    content.descriptions
                )
                ui = ui.merge(found)
                if (!found.biometricPrompt && SystemUiSignatures.looksRelated(content.ids)) {
                    unknownIds = content.ids.sorted().take(25).joinToString(", ")
                }
            } else if (
                window.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                (window.isActive || window.isFocused) &&
                packageName != service.packageName
            ) {
                ui = ui.merge(UiSnapshot(appOverLockscreen = true))
            }
        }
        return Result(ui, unknownIds)
    }

    /** Обхід у ширину тільки видимих вузлів; список сповіщень не обходиться. */
    private fun collect(root: AccessibilityNodeInfo): WindowContent {
        val ids = mutableSetOf<String>()
        val descriptions = mutableListOf<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var inspected = 0

        while (queue.isNotEmpty() && inspected < MAX_NODES_PER_WINDOW) {
            val node = queue.removeFirst()
            inspected++
            if (!node.isVisibleToUser) continue

            val id = node.viewIdResourceName?.let { SystemUiSignatures.entryName(it) }
            if (id != null) ids.add(id)
            node.contentDescription?.let { descriptions.add(it.toString()) }

            if (id == "notification_stack_scroller") continue
            for (index in 0 until node.childCount.coerceAtMost(MAX_CHILDREN)) {
                node.getChild(index)?.let { queue.add(it) }
            }
        }
        return WindowContent(ids, descriptions)
    }
}
