package com.nothing.glyphfp.service

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object ServiceStateBus {
    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _testTriggerEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val testTriggerEvents: SharedFlow<Unit> = _testTriggerEvents.asSharedFlow()

    fun setServiceRunning(running: Boolean) {
        _isServiceRunning.value = running
    }

    fun requestTestAnimation() {
        _testTriggerEvents.tryEmit(Unit)
    }
}
