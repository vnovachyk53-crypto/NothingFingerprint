package com.nothing.glyphfp.service
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object ServiceStateBus {
    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _testTriggerEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val testTriggerEvents: SharedFlow<Unit> = _testTriggerEvents.asSharedFlow()

    private var lockscreenOk = false
    private var promptOk = false
    private var lockscreenStatus = "ще не перевірявся"
    private var promptStatus = "ще не з'являвся"

    private val _diagnostics = MutableStateFlow(describe())
    val diagnostics: StateFlow<String> = _diagnostics.asStateFlow()

    /** [blockedReason] == null означає, що на екрані блокування тригер активний. */
    fun reportLockscreen(blockedReason: String?) {
        if (blockedReason == null) {
            lockscreenOk = true
            lockscreenStatus = "тригер активний"
        } else if (!lockscreenOk) {
            lockscreenStatus = "тригер вимкнений: $blockedReason"
        }
        _diagnostics.value = describe()
    }

    fun reportBiometricPrompt(byOverlay: Boolean = false) {
        promptOk = true
        promptStatus = if (byOverlay) "розпізнано за системним вікном" else "розпізнано"
        _diagnostics.value = describe()
    }

    fun reportUnknownWindow(ids: String) {
        if (!promptOk) {
            promptStatus = "нерозпізнане вікно SystemUI, ID: $ids"
            _diagnostics.value = describe()
        }
    }

    fun setServiceRunning(running: Boolean) {
        _isServiceRunning.value = running
    }

    fun requestTestAnimation() {
        _testTriggerEvents.tryEmit(Unit)
    }

    private fun describe(): String {
        return "Екран блокування: $lockscreenStatus.\nЗапит біометрії: $promptStatus."
    }
}
