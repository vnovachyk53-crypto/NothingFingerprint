package com.nothing.glyphfp

import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.nothing.glyphfp.data.SettingsRepository
import com.nothing.glyphfp.service.FingerprintOverlayService
import com.nothing.glyphfp.ui.MainScreen
import com.nothing.glyphfp.ui.theme.NothingGlyphTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepository: SettingsRepository

    private var accessibilityEnabled by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Інтерфейс завжди чорний, тому іконки системних панелей мають бути світлими.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        settingsRepository = SettingsRepository(applicationContext)

        setContent {
            NothingGlyphTheme {
                val filePicker = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri ->
                    if (uri != null) {
                        try {
                            contentResolver.takePersistableUriPermission(
                                uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        } catch (_: Exception) {
                            Toast.makeText(
                                this@MainActivity,
                                "Не вдалося зберегти доступ до файлу. Оберіть файл ще раз.",
                                Toast.LENGTH_LONG
                            ).show()
                            return@rememberLauncherForActivityResult
                        }

                        lifecycleScope.launch {
                            runCatching {
                                settingsRepository.saveCustomMedia(uri)
                            }.onSuccess {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Файл анімації додано.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }.onFailure { error ->
                                Toast.makeText(
                                    this@MainActivity,
                                    error.message ?: "Не вдалося відкрити цей файл.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                }

                MainScreen(
                    repository = settingsRepository,
                    isAccessibilityEnabled = accessibilityEnabled,
                    onPickCustomFile = { filePicker.launch(arrayOf("*/*")) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accessibilityEnabled = isFingerprintAccessibilityEnabled()
    }

    private fun isFingerprintAccessibilityEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()

        if (Settings.Secure.getInt(
                contentResolver,
                Settings.Secure.ACCESSIBILITY_ENABLED,
                0
            ) != 1
        ) {
            return false
        }

        val thisService = ComponentName(this, FingerprintOverlayService::class.java)
        return enabledServices.split(':').any { flattenedName ->
            ComponentName.unflattenFromString(flattenedName) == thisService
        }
    }
}
