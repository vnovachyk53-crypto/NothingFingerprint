package com.nothing.glyphfp.ui

import android.provider.Settings
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.nothing.glyphfp.data.SettingsRepository
import com.nothing.glyphfp.model.AnimationPreset
import com.nothing.glyphfp.model.ScannerConfig
import com.nothing.glyphfp.renderer.FingerprintAnimationView
import com.nothing.glyphfp.service.Haptics
import com.nothing.glyphfp.service.ServiceStateBus
import com.nothing.glyphfp.ui.components.CalibrationReticleOverlay
import com.nothing.glyphfp.ui.components.DotMatrixBanner
import com.nothing.glyphfp.ui.components.NothingCard
import com.nothing.glyphfp.ui.components.NothingPillButton
import com.nothing.glyphfp.ui.components.NothingTelemetrySlider
import com.nothing.glyphfp.ui.components.StatusBadge
import com.nothing.glyphfp.ui.theme.NothingBlack
import com.nothing.glyphfp.ui.theme.NothingBorder
import com.nothing.glyphfp.ui.theme.NothingGray
import com.nothing.glyphfp.ui.theme.NothingRed
import com.nothing.glyphfp.ui.theme.NothingWhite
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun MainScreen(
    repository: SettingsRepository,
    isAccessibilityEnabled: Boolean,
    onPickCustomFile: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val config by repository.configFlow.collectAsState(initial = ScannerConfig())
    val busRunning by ServiceStateBus.isServiceRunning.collectAsState()
    val serviceActive = isAccessibilityEnabled || busRunning

    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx() }.roundToInt().coerceAtLeast(1080)
    val screenHeightPx = with(density) { configuration.screenHeightDp.dp.toPx() }.roundToInt().coerceAtLeast(2412)

    var showReticle by remember { mutableStateOf(true) }
    var previewHostView by remember { mutableStateOf<FingerprintAnimationView?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NothingBlack)
    ) {
        // Прев'ю розташоване позаду елементів керування, щоб AndroidView не перекривав кнопки.
        AndroidView(
            factory = { ctx ->
                FingerprintAnimationView(ctx).also { view ->
                    view.updateConfig(config)
                    previewHostView = view
                }
            },
            update = { view -> view.updateConfig(config) },
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Заголовок у стилі Nothing OS 5.0
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                DotMatrixBanner(text = "GLYPH // FP (3A)")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "NOTHING OS 5.0 // OPTICAL SENSOR ENGINE",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Text(
                        text = "API 37",
                        style = MaterialTheme.typography.labelSmall,
                        color = NothingRed
                    )
                }
            }

            // 1. Статус-картка AccessibilityService
            NothingCard(isSelected = !serviceActive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ACCESSIBILITY OVERLAY",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (serviceActive) {
                                "Сервіс працює на екрані блокування та в системному запиті біометрії."
                            } else {
                                "Увімкніть сервіс доступності для відображення анімації поверх екрана блокування."
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    StatusBadge(isActive = serviceActive)
                }

                Spacer(modifier = Modifier.height(14.dp))

                NothingPillButton(
                    label = if (serviceActive) "НАЛАШТУВАННЯ СЕРВІСУ" else "УВІМКНУТИ СЕРВІС",
                    isPrimary = !serviceActive,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                    }
                )
            }

            // 2. Вибір анімації (2 пресети + кастомний файл)
            Text(
                text = "ANIMATION PRESETS // 120 FPS CANVAS",
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(top = 4.dp)
            )

            PresetItemCard(
                preset = AnimationPreset.DOT_MATRIX_ASSEMBLY,
                selected = config.preset == AnimationPreset.DOT_MATRIX_ASSEMBLY,
                onClick = {
                    scope.launch { repository.selectPreset(AnimationPreset.DOT_MATRIX_ASSEMBLY) }
                }
            )

            PresetItemCard(
                preset = AnimationPreset.GLYPH_PULSE_RIPPLE,
                selected = config.preset == AnimationPreset.GLYPH_PULSE_RIPPLE,
                onClick = {
                    scope.launch { repository.selectPreset(AnimationPreset.GLYPH_PULSE_RIPPLE) }
                }
            )

            // Імпорт кастомного файлу (.json / .gif / .webm)
            NothingCard(
                isSelected = config.preset == AnimationPreset.CUSTOM_FILE,
                onClick = {
                    if (config.customUriString != null) {
                        scope.launch { repository.selectPreset(AnimationPreset.CUSTOM_FILE) }
                    } else {
                        onPickCustomFile()
                    }
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = AnimationPreset.CUSTOM_FILE.code,
                            style = MaterialTheme.typography.labelSmall,
                            color = NothingRed
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = AnimationPreset.CUSTOM_FILE.title,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = config.customFileName?.let {
                                "Файл: $it (${config.customMediaType.name})"
                            } ?: "Підтримка .JSON (Lottie), прозорих .GIF та .WEBM",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    IconButton(
                        onClick = onPickCustomFile,
                        modifier = Modifier
                            .size(42.dp)
                            .border(1.dp, NothingBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FileUpload,
                            contentDescription = "Імпортувати файл",
                            tint = NothingWhite
                        )
                    }
                }
            }

            // 3. Інтерактивне калібрування сканера
            NothingCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "OPTICAL SENSOR CALIBRATION",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "NOTHING PHONE (3A) // DEFAULT: X=540, Y=2110",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    IconButton(
                        onClick = {
                            scope.launch { repository.resetCalibration() }
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .border(1.dp, NothingBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Refresh,
                            contentDescription = "Скинути координати",
                            tint = NothingGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                val xPx = (config.centerXNormalized * screenWidthPx).roundToInt()
                val yPx = (config.centerYNormalized * screenHeightPx).roundToInt()

                NothingTelemetrySlider(
                    label = "CENTER X AXIS",
                    valueText = "$xPx PX (${(config.centerXNormalized * 100).roundToInt()}%)",
                    value = config.centerXNormalized,
                    valueRange = 0.10f..0.90f,
                    onValueChange = { v ->
                        showReticle = true
                        scope.launch { repository.updateCenterX(v) }
                    }
                )

                NothingTelemetrySlider(
                    label = "CENTER Y AXIS",
                    valueText = "$yPx PX (${(config.centerYNormalized * 100).roundToInt()}%)",
                    value = config.centerYNormalized,
                    valueRange = 0.55f..0.96f,
                    onValueChange = { v ->
                        showReticle = true
                        scope.launch { repository.updateCenterY(v) }
                    }
                )

                NothingTelemetrySlider(
                    label = "SCANNER RADIUS",
                    valueText = "${config.scannerRadiusDp.roundToInt()} DP",
                    value = config.scannerRadiusDp,
                    valueRange = 24f..70f,
                    onValueChange = { v ->
                        showReticle = true
                        scope.launch { repository.updateScannerRadius(v) }
                    }
                )

                NothingTelemetrySlider(
                    label = "ANIMATION SCALE",
                    valueText = String.format(Locale.US, "%.2fX", config.scale),
                    value = config.scale,
                    valueRange = 0.50f..2.00f,
                    onValueChange = { v ->
                        scope.launch { repository.updateScale(v) }
                    }
                )

                NothingTelemetrySlider(
                    label = "PLAYBACK SPEED",
                    valueText = String.format(Locale.US, "%.2fX", config.speed),
                    value = config.speed,
                    valueRange = 0.40f..2.50f,
                    onValueChange = { v ->
                        scope.launch { repository.updateSpeed(v) }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NothingPillButton(
                        label = "ТЕСТ АНІМАЦІЇ",
                        isPrimary = true,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            // Увімкнений у налаштуваннях сервіс ще не означає, що він запущений.
                            if (busRunning) {
                                ServiceStateBus.requestTestAnimation()
                            } else {
                                previewHostView?.updateConfig(config)
                                previewHostView?.triggerAnimation()
                                if (config.hapticEnabled) Haptics.click(context)
                            }
                        }
                    )

                    NothingPillButton(
                        label = if (showReticle) "ПРИЦІЛ: ON" else "ПРИЦІЛ: OFF",
                        isPrimary = false,
                        onClick = { showReticle = !showReticle }
                    )
                }
            }

            // 4. Коли запускається анімація
            NothingCard {
                Text(
                    text = "TRIGGERS",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Екран блокування: анімація стартує при розблокуванні телефону " +
                            "(ACTION_USER_PRESENT) і при дотику. Запит біометрії в застосунках " +
                            "(банкінг): маячок на сканері, анімація при дотику або коли вікно зникає. " +
                            "У решті застосунків сервіс нічого не робить.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // 5. Маячок і вібровідгук
            NothingCard {
                Text(
                    text = "SMART OPTICAL BEACON & FEEDBACK",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                NothingPillButton(
                    label = if (config.beaconEnabled) "BEACON: ON" else "BEACON: OFF",
                    isPrimary = config.beaconEnabled,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch { repository.setBeaconEnabled(!config.beaconEnabled) }
                    }
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Пульсуюче точкове кільце на сканері під час системного запиту біометрії.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                NothingPillButton(
                    label = if (config.hapticEnabled) "ВІБРОВІДГУК: ON" else "ВІБРОВІДГУК: OFF",
                    isPrimary = config.hapticEnabled,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch { repository.setHapticEnabled(!config.hapticEnabled) }
                    }
                )
            }

            Spacer(modifier = Modifier.height(140.dp))
        }

        // Візуальний приціл оптичного сканера поверх усього екрана для точного калібрування
        if (showReticle) {
            CalibrationReticleOverlay(
                centerXNormalized = config.centerXNormalized,
                centerYNormalized = config.centerYNormalized,
                scale = config.scale,
                radiusDp = config.scannerRadiusDp,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun PresetItemCard(
    preset: AnimationPreset,
    selected: Boolean,
    onClick: () -> Unit
) {
    NothingCard(
        isSelected = selected,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = preset.code,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (selected) NothingRed else NothingGray
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = preset.title,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = preset.subtitle,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(
                        color = if (selected) NothingRed else NothingBlack,
                        shape = CircleShape
                    )
                    .border(
                        width = 1.dp,
                        color = if (selected) NothingRed else NothingBorder,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (selected) Icons.Outlined.Fingerprint else Icons.Outlined.PlayArrow,
                    contentDescription = null,
                    tint = NothingWhite,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}