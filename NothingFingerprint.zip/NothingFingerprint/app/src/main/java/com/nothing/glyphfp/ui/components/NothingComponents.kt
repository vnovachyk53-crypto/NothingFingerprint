package com.nothing.glyphfp.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nothing.glyphfp.ui.theme.NothingBlack
import com.nothing.glyphfp.ui.theme.NothingBorder
import com.nothing.glyphfp.ui.theme.NothingGray
import com.nothing.glyphfp.ui.theme.NothingMuted
import com.nothing.glyphfp.ui.theme.NothingRed
import com.nothing.glyphfp.ui.theme.NothingSurface
import com.nothing.glyphfp.ui.theme.NothingWhite

/**
 * Процедурний точковий дисплей у стилі Nothing Dot-Matrix 5x7.
 */
@Composable
fun DotMatrixBanner(
    text: String,
    modifier: Modifier = Modifier,
    dotColor: Color = NothingWhite,
    accentLastChars: Int = 2
) {
    val clean = text.uppercase()
    Canvas(
        modifier = modifier
            .height(26.dp)
            .fillMaxWidth()
    ) {
        // Крок точок зменшується, якщо напис не вміщується по ширині або висоті.
        val pitch = minOf(
            4.1.dp.toPx(),
            size.width / (clean.length.coerceAtLeast(1) * 6f),
            size.height / 7f
        )
        val dotRadius = pitch * 0.4f
        val charAdvance = pitch * 6f
        var cursorX = 0f

        clean.forEachIndexed { index, ch ->
            val glyph = DotGlyphFont.glyphFor(ch)
            val isAccent = index >= clean.length - accentLastChars && ch != ' '
            val activeColor = if (isAccent) NothingRed else dotColor

            for (row in 0 until 7) {
                val rowMask = glyph[row]
                for (col in 0 until 5) {
                    val isSet = ((rowMask shr (4 - col)) and 1) == 1
                    drawCircle(
                        color = if (isSet) activeColor else Color(0xFF1A1A1A),
                        radius = dotRadius,
                        center = Offset(
                            x = cursorX + col * pitch + dotRadius,
                            y = row * pitch + dotRadius
                        )
                    )
                }
            }
            cursorX += charAdvance
        }
    }
}

@Composable
fun NothingCard(
    modifier: Modifier = Modifier,
    isSelected: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (isSelected) NothingRed else NothingBorder
    val shape = RoundedCornerShape(18.dp)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        color = NothingSurface,
        shape = shape,
        border = BorderStroke(1.dp, borderColor),
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun NothingPillButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true
) {
    val bgColor = if (isPrimary) NothingRed else NothingSurface
    val textColor = NothingWhite
    val border = if (isPrimary) null else BorderStroke(1.dp, NothingBorder)

    Surface(
        modifier = modifier
            .height(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        color = bgColor,
        shape = CircleShape,
        border = border,
        shadowElevation = 0.dp
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.4.sp,
                color = textColor
            )
        }
    }
}

@Composable
fun NothingTelemetrySlider(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                letterSpacing = 1.2.sp,
                color = NothingGray
            )
            Text(
                text = valueText,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.sp,
                color = NothingWhite
            )
        }

        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = NothingRed,
                activeTrackColor = NothingWhite,
                inactiveTrackColor = NothingBorder
            )
        )
    }
}

/**
 * Інтерактивний приціл калібрування оптичного сенсора, що накладається поверх екрана в режимі налаштування.
 */
@Composable
fun CalibrationReticleOverlay(
    centerXNormalized: Float,
    centerYNormalized: Float,
    scale: Float,
    radiusDp: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val cx = size.width * centerXNormalized
        val cy = size.height * centerYNormalized
        val radius = radiusDp.dp.toPx()
        val crossSize = 54.dp.toPx() * scale

        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)

        // Пунктирні осі перехрестя
        drawLine(
            color = NothingWhite.copy(alpha = 0.35f),
            start = Offset(cx - crossSize, cy),
            end = Offset(cx + crossSize, cy),
            strokeWidth = 1.dp.toPx(),
            pathEffect = dashEffect
        )
        drawLine(
            color = NothingWhite.copy(alpha = 0.35f),
            start = Offset(cx, cy - crossSize),
            end = Offset(cx, cy + crossSize),
            strokeWidth = 1.dp.toPx(),
            pathEffect = dashEffect
        )

        // Контур оптичного сенсора Nothing Phone (3a)
        drawCircle(
            color = NothingRed,
            radius = radius,
            center = Offset(cx, cy),
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawCircle(
            color = NothingRed,
            radius = 3.dp.toPx(),
            center = Offset(cx, cy)
        )
    }
}

@Composable
fun StatusBadge(isActive: Boolean) {
    val dotColor = if (isActive) NothingRed else NothingMuted
    val text = if (isActive) "ACTIVE // 120HZ" else "DISABLED"

    Row(
        modifier = Modifier
            .background(NothingBlack, CircleShape)
            .border(1.dp, if (isActive) NothingRed else NothingBorder, CircleShape)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(dotColor, CircleShape)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 1.2.sp,
            color = if (isActive) NothingWhite else NothingGray
        )
    }
}

private object DotGlyphFont {
    private val map = mapOf(
        'G' to intArrayOf(0b01110, 0b10001, 0b10000, 0b10111, 0b10001, 0b10001, 0b01110),
        'L' to intArrayOf(0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111),
        'Y' to intArrayOf(0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100, 0b00100),
        'P' to intArrayOf(0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000),
        'H' to intArrayOf(0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001),
        'F' to intArrayOf(0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000),
        'O' to intArrayOf(0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110),
        'S' to intArrayOf(0b01111, 0b10000, 0b10000, 0b01110, 0b00001, 0b00001, 0b11110),
        '3' to intArrayOf(0b11110, 0b00001, 0b00001, 0b01110, 0b00001, 0b00001, 0b11110),
        'A' to intArrayOf(0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001),
        '/' to intArrayOf(0b00001, 0b00010, 0b00010, 0b00100, 0b01000, 0b01000, 0b10000),
        '(' to intArrayOf(0b00010, 0b00100, 0b01000, 0b01000, 0b01000, 0b00100, 0b00010),
        ')' to intArrayOf(0b01000, 0b00100, 0b00010, 0b00010, 0b00010, 0b00100, 0b01000),
        ' ' to intArrayOf(0, 0, 0, 0, 0, 0, 0)
    )

    fun glyphFor(c: Char): IntArray = map[c] ?: intArrayOf(
        0b11111, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b11111
    )
}