package com.nothing.glyphfp.model
enum class AnimationPreset(
    val id: String,
    val title: String,
    val code: String,
    val subtitle: String
) {
    DOT_MATRIX_ASSEMBLY(
        id = "dot_matrix",
        title = "DOT MATRIX ASSEMBLY",
        code = "PRS // 01",
        subtitle = "Хвиля піксельної сітки Nothing з червоними акцентами"
    ),
    GLYPH_PULSE_RIPPLE(
        id = "glyph_pulse",
        title = "GLYPH PULSE RIPPLE",
        code = "PRS // 02",
        subtitle = "Концентричні сегменти гліфів та мікро-іскри"
    ),
    CUSTOM_FILE(
        id = "custom_file",
        title = "CUSTOM MEDIA LAYER",
        code = "EXT // 03",
        subtitle = "Власний файл .JSON (Lottie), .GIF або .WEBM"
    );

    companion object {
        fun fromId(id: String?): AnimationPreset {
            return entries.firstOrNull { it.id == id } ?: DOT_MATRIX_ASSEMBLY
        }
    }
}

enum class CustomMediaType {
    NONE,
    LOTTIE_JSON,
    ANIMATED_GIF,
    TRANSPARENT_WEBM
}

enum class TriggerMode(val id: String) {
    BIOMETRIC_TOUCH("biometric_touch"),
    AFTER_UNLOCK("after_unlock");

    companion object {
        fun fromId(id: String?): TriggerMode {
            return entries.firstOrNull { it.id == id } ?: BIOMETRIC_TOUCH
        }
    }
}

/**
 * Конфігурація калібрування оптичного сканера.
 * Дефолтні значення (centerX = 0.50f, centerY = 0.875f) точні для Nothing Phone (3a) (1080x2412).
 */
data class ScannerConfig(
    val preset: AnimationPreset = AnimationPreset.DOT_MATRIX_ASSEMBLY,
    val centerXNormalized: Float = 0.50f,
    val centerYNormalized: Float = 0.875f,
    val scale: Float = 1.0f,
    val speed: Float = 1.0f,
    val customUriString: String? = null,
    val customFileName: String? = null,
    val customMediaType: CustomMediaType = CustomMediaType.NONE,
    val scannerRadiusDp: Float = DEFAULT_SCANNER_RADIUS_DP,
    val triggerMode: TriggerMode = TriggerMode.BIOMETRIC_TOUCH,
    val beaconEnabled: Boolean = true,
    val hapticEnabled: Boolean = true
)

/** Радіус кола сканера в dp: приціл калібрування та кільце маячка. */
const val DEFAULT_SCANNER_RADIUS_DP = 40f

