package com.nothing.glyphfp.renderer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.view.Choreographer
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import androidx.core.graphics.withScale
import androidx.core.graphics.withTranslation
import com.airbnb.lottie.LottieCompositionFactory
import com.airbnb.lottie.LottieDrawable
import com.nothing.glyphfp.model.AnimationPreset
import com.nothing.glyphfp.model.CustomMediaType
import com.nothing.glyphfp.model.ScannerConfig
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class FingerprintAnimationView(context: Context) : FrameLayout(context) {

    private companion object {
        const val MAX_VIDEO_SECONDS = 10f
    }

    private var config: ScannerConfig = ScannerConfig()
    private var isPlaying: Boolean = false

    /** Чи грає анімація зараз; повторний запуск під час відтворення не потрібен. */
    val isAnimating: Boolean get() = isPlaying
    private var isFadingOut: Boolean = false
    private var progress: Float = 0f
    private var masterAlpha: Float = 0f
    private var lastFrameNanos: Long = 0L
    private var elapsedSeconds: Float = 0f

    private val density = resources.displayMetrics.density
    private val canvasView = InternalCanvasView(context)
    private val webmTextureView = TextureView(context).apply {
        isOpaque = false
        visibility = View.GONE
    }

    private var lottieDrawable: LottieDrawable? = null
    private var gifDrawable: AnimatedImageDrawable? = null
    private var loadedMediaUri: String? = null
    private var mediaPlayer: MediaPlayer? = null
    private var videoSurface: Surface? = null

    private val choreographer = Choreographer.getInstance()
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isPlaying) {
                lastFrameNanos = 0L
                return
            }
            val dt = if (lastFrameNanos == 0L) {
                1f / 120f
            } else {
                ((frameTimeNanos - lastFrameNanos) / 1_000_000_000.0)
                    .toFloat()
                    .coerceIn(0.001f, 0.05f)
            }
            lastFrameNanos = frameTimeNanos
            stepSimulation(dt)
            canvasView.invalidate()
            if (isPlaying) {
                choreographer.postFrameCallback(this)
            }
        }
    }

    init {
        setWillNotDraw(true)
        addView(
            canvasView,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        )
        addView(
            webmTextureView,
            LayoutParams(
                (260f * density).toInt(),
                (260f * density).toInt(),
                Gravity.TOP or Gravity.START
            )
        )
        setupTextureListener()
    }

    fun updateConfig(newConfig: ScannerConfig) {
        val uriChanged = config.customUriString != newConfig.customUriString ||
                config.customMediaType != newConfig.customMediaType
        val switchedAwayFromCustom = config.preset == AnimationPreset.CUSTOM_FILE &&
                newConfig.preset != AnimationPreset.CUSTOM_FILE
        config = newConfig

        if (switchedAwayFromCustom) {
            stopCustomMediaPlayback()
        }
        if (uriChanged || (newConfig.preset == AnimationPreset.CUSTOM_FILE && loadedMediaUri == null)) {
            prepareCustomMedia()
        }
        updateWebmLayoutBounds()
        if (isPlaying) {
            canvasView.invalidate()
        }
    }

    fun triggerAnimation() {
        progress = 0f
        elapsedSeconds = 0f
        masterAlpha = 1f
        isFadingOut = false
        canvasView.resetParticles()

        if (config.preset == AnimationPreset.CUSTOM_FILE) {
            startCustomMediaPlayback()
        } else {
            hideWebmView()
        }

        if (!isPlaying) {
            isPlaying = true
            lastFrameNanos = 0L
            choreographer.postFrameCallback(frameCallback)
        }
    }

    fun fadeOutAndStop() {
        if (!isPlaying) return
        isFadingOut = true
    }

    fun stopImmediately() {
        isPlaying = false
        isFadingOut = false
        progress = 0f
        masterAlpha = 0f
        lastFrameNanos = 0L
        choreographer.removeFrameCallback(frameCallback)
        stopCustomMediaPlayback()
        canvasView.invalidate()
    }

    private fun stepSimulation(dt: Float) {
        val baseDuration = when (config.preset) {
            AnimationPreset.DOT_MATRIX_ASSEMBLY -> 1.15f
            AnimationPreset.GLYPH_PULSE_RIPPLE -> 1.05f
            // Lottie грає зі своєю тривалістю, інші файли — типові 1.6 с.
            AnimationPreset.CUSTOM_FILE ->
                lottieDrawable
                    ?.takeIf { config.customMediaType == CustomMediaType.LOTTIE_JSON }
                    ?.composition
                    ?.let { it.duration / 1000f }
                    ?: 1.60f
        }
        val effectiveDuration = (baseDuration / config.speed).coerceIn(0.25f, 4.0f)
        progress += dt / effectiveDuration
        elapsedSeconds += dt

        if (config.preset == AnimationPreset.CUSTOM_FILE &&
            config.customMediaType == CustomMediaType.LOTTIE_JSON
        ) {
            lottieDrawable?.progress = progress.coerceIn(0f, 1f)
        }

        // Для вбудованих ефектів залишаємо раннє затухання, а власний Lottie-файл
        // отримує повний цикл від 0 до 100% перед згасанням.
        val isTimedVideo = config.preset == AnimationPreset.CUSTOM_FILE &&
                config.customMediaType == CustomMediaType.TRANSPARENT_WEBM
        val fadeStart = if (config.preset == AnimationPreset.CUSTOM_FILE) 1f else 0.72f
        if (!isTimedVideo && progress >= fadeStart && !isFadingOut) {
            isFadingOut = true
        }
        // Страховка: якщо відео не запустилося і не повідомило про кінець, не крутимо цикл вічно.
        if (isTimedVideo && elapsedSeconds >= MAX_VIDEO_SECONDS) {
            isFadingOut = true
        }

        if (isFadingOut) {
            val fadeSpeed = (3.4f * config.speed).coerceIn(1.5f, 8.0f)
            masterAlpha = (masterAlpha - dt * fadeSpeed).coerceAtLeast(0f)
            if (webmTextureView.visibility == View.VISIBLE) {
                webmTextureView.alpha = masterAlpha
            }
            if (masterAlpha <= 0f) {
                stopImmediately()
            }
        }
    }

    private fun prepareCustomMedia() {
        val uriStr = config.customUriString ?: return
        if (uriStr == loadedMediaUri) return
        loadedMediaUri = uriStr

        lottieDrawable?.callback = null
        lottieDrawable = null
        gifDrawable?.stop()
        gifDrawable?.callback = null
        gifDrawable = null
        releaseMediaPlayer()

        val uri = runCatching { Uri.parse(uriStr) }.getOrNull() ?: return

        when (config.customMediaType) {
            CustomMediaType.LOTTIE_JSON -> {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                        val json = reader.readText()
                        val result = LottieCompositionFactory.fromJsonStringSync(json, uriStr)
                        result.value?.let { comp ->
                            lottieDrawable = LottieDrawable().apply {
                                composition = comp
                                repeatCount = 0
                                callback = canvasView
                            }
                        }
                    }
                }
            }

            CustomMediaType.ANIMATED_GIF -> {
                runCatching {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    val drawable = ImageDecoder.decodeDrawable(source)
                    if (drawable is AnimatedImageDrawable) {
                        drawable.repeatCount = 1
                        drawable.callback = canvasView
                        gifDrawable = drawable
                    }
                }
            }

            CustomMediaType.TRANSPARENT_WEBM -> {
                updateWebmLayoutBounds()
            }

            CustomMediaType.NONE -> Unit
        }
    }

    private fun startCustomMediaPlayback() {
        when (config.customMediaType) {
            CustomMediaType.LOTTIE_JSON -> {
                hideWebmView()
                lottieDrawable?.progress = 0f
            }

            CustomMediaType.ANIMATED_GIF -> {
                hideWebmView()
                gifDrawable?.stop()
                gifDrawable?.start()
            }

            CustomMediaType.TRANSPARENT_WEBM -> {
                updateWebmLayoutBounds()
                webmTextureView.alpha = 1f
                webmTextureView.visibility = View.VISIBLE
                playWebmFromSurface()
            }

            CustomMediaType.NONE -> hideWebmView()
        }
    }

    private fun stopCustomMediaPlayback() {
        gifDrawable?.stop()
        releaseMediaPlayer()
        hideWebmView()
    }

    private fun hideWebmView() {
        if (webmTextureView.visibility != View.GONE) {
            webmTextureView.visibility = View.GONE
        }
    }

    private fun updateWebmLayoutBounds() {
        val w = if (width > 0) width else resources.displayMetrics.widthPixels
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        val boxSize = (240f * density * config.scale).toInt().coerceAtLeast(64)
        val cx = (w * config.centerXNormalized).toInt()
        val cy = (h * config.centerYNormalized).toInt()

        val lp = (webmTextureView.layoutParams as? LayoutParams) ?: LayoutParams(boxSize, boxSize)
        lp.width = boxSize
        lp.height = boxSize
        lp.leftMargin = cx - boxSize / 2
        lp.topMargin = cy - boxSize / 2
        webmTextureView.layoutParams = lp
    }

    private fun setupTextureListener() {
        webmTextureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                videoSurface?.release()
                videoSurface = Surface(surface)
                if (isPlaying && config.preset == AnimationPreset.CUSTOM_FILE &&
                    config.customMediaType == CustomMediaType.TRANSPARENT_WEBM
                ) {
                    playWebmFromSurface()
                }
            }

            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) = Unit

            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                releaseMediaPlayer()
                videoSurface?.release()
                videoSurface = null
                return true
            }

            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
        }
    }

    private fun playWebmFromSurface() {
        val surface = videoSurface ?: return
        val uriStr = config.customUriString ?: return
        val uri = runCatching { Uri.parse(uriStr) }.getOrNull() ?: return

        releaseMediaPlayer()
        runCatching {
            // Посилання зберігаємо одразу, щоб звільнити плеєр і після помилки налаштування.
            val player = MediaPlayer()
            mediaPlayer = player
            player.apply {
                setDataSource(context, uri)
                setSurface(surface)
                isLooping = false
                setOnPreparedListener { mp ->
                    if (isPlaying && webmTextureView.visibility == View.VISIBLE) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            runCatching {
                                mp.playbackParams = mp.playbackParams.setSpeed(config.speed.coerceIn(0.5f, 2.0f))
                            }
                        }
                        mp.start()
                    } else {
                        releaseMediaPlayer()
                    }
                }
                setOnCompletionListener {
                    if (isPlaying) isFadingOut = true
                }
                setOnErrorListener { _, _, _ ->
                    isFadingOut = true
                    true
                }
                prepareAsync()
            }
        }.onFailure {
            releaseMediaPlayer()
            isFadingOut = true
        }
    }

    private fun releaseMediaPlayer() {
        val player = mediaPlayer
        mediaPlayer = null
        runCatching { player?.stop() }
        runCatching { player?.release() }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        post { updateWebmLayoutBounds() }
    }

    override fun onDetachedFromWindow() {
        stopImmediately()
        lottieDrawable?.callback = null
        gifDrawable?.callback = null
        releaseMediaPlayer()
        super.onDetachedFromWindow()
    }

    /**
     * Високопродуктивний Canvas-рендерер (Zero-Allocation на кадр).
     */
    private inner class InternalCanvasView(context: Context) : View(context) {

        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }

        private val glyphCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }

        private val glyphGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }

        private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }

        private val arcBounds = RectF()

        // Преалокований пул мікро-іскор для Glyph Pulse Ripple
        private val sparkCount = 40
        private val sparkAngles = FloatArray(sparkCount)
        private val sparkSpeedMult = FloatArray(sparkCount)
        private val sparkSizes = FloatArray(sparkCount)
        private val sparkIsRed = BooleanArray(sparkCount)

        init {
            // Окремий апаратний шар не потрібен: вміст змінюється щокадру, а шар на весь екран
            // лише додає роботу GPU. Апаратне прискорення вікна діє й без нього.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                requestedFrameRate = 120f
            }
            resetParticles()
        }

        fun resetParticles() {
            for (i in 0 until sparkCount) {
                sparkAngles[i] = ((i.toFloat() / sparkCount) * 360f + Random.nextFloat() * 9f) * (PI.toFloat() / 180f)
                sparkSpeedMult[i] = 0.65f + Random.nextFloat() * 0.75f
                sparkSizes[i] = (1.4f + Random.nextFloat() * 2.2f) * density
                sparkIsRed[i] = (i % 4 == 0)
            }
        }

        // Без цього View ігнорує запити кадрів від Lottie/GIF Drawable.
        override fun verifyDrawable(who: Drawable): Boolean {
            return who === lottieDrawable || who === gifDrawable || super.verifyDrawable(who)
        }

        override fun onDraw(canvas: Canvas) {
            if (!isPlaying || masterAlpha <= 0.001f) return

            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            val cx = w * config.centerXNormalized
            val cy = h * config.centerYNormalized

            when (config.preset) {
                AnimationPreset.DOT_MATRIX_ASSEMBLY -> drawDotMatrixAssembly(canvas, w, h, cx, cy)
                AnimationPreset.GLYPH_PULSE_RIPPLE -> drawGlyphPulseRipple(canvas, cx, cy)
                AnimationPreset.CUSTOM_FILE -> drawCustomCanvasMedia(canvas, cx, cy)
            }
        }

        /**
         * Пресет 1: Dot Matrix Assembly
         * Хвиля точкової матриці у стилі Nothing OS, що розходиться від сканера по всьому екрану.
         */
        private fun drawDotMatrixAssembly(
            canvas: Canvas,
            width: Float,
            height: Float,
            cx: Float,
            cy: Float
        ) {
            val spacing = (24f * density * config.scale.coerceIn(0.75f, 1.45f)).coerceAtLeast(16f * density)
            val baseRadius = 1.35f * density
            val maxPeakRadius = 5.4f * density * config.scale.coerceIn(0.7f, 1.6f)

            val maxCornerDist = max(
                max(hypot(cx, cy), hypot(width - cx, cy)),
                max(hypot(cx, height - cy), hypot(width - cx, height - cy))
            )

            // Крива прискорення хвилі (швидкий старт від пальця, плавне розтікання до країв)
            val easedProgress = 1f - (1f - progress.coerceIn(0f, 1.25f)) * (1f - progress.coerceIn(0f, 1.25f))
            val primaryWaveRadius = easedProgress * maxCornerDist * 1.15f
            val secondaryWaveRadius = primaryWaveRadius * 0.56f
            val bandWidth = 145f * density * config.scale

            val cols = (width / spacing).toInt() + 1
            val rows = (height / spacing).toInt() + 1

            for (row in 0..rows) {
                val y = row * spacing
                val dy = y - cy
                val dySq = dy * dy

                for (col in 0..cols) {
                    val x = col * spacing
                    val dx = x - cx
                    val dist = kotlin.math.sqrt(dx * dx + dySq)

                    val deltaPrimary = kotlin.math.abs(dist - primaryWaveRadius)
                    val deltaSecondary = kotlin.math.abs(dist - secondaryWaveRadius)

                    if (deltaPrimary > bandWidth && deltaSecondary > bandWidth * 0.75f) continue

                    val p1 = if (deltaPrimary < bandWidth) {
                        val t = 1f - (deltaPrimary / bandWidth)
                        t * t * (3f - 2f * t)
                    } else 0f

                    val p2 = if (deltaSecondary < bandWidth * 0.75f) {
                        val t = 1f - (deltaSecondary / (bandWidth * 0.75f))
                        (t * t * (3f - 2f * t)) * 0.55f
                    } else 0f

                    val energy = max(p1, p2)
                    if (energy <= 0.02f) continue

                    // Детермінований розподіл фірмових кольорів Nothing (#D71921, #FFFFFF, #A0A0A0)
                    val cellHash = ((col * 73856093) xor (row * 19349663)) and 0xFF
                    val color = when {
                        cellHash < 36 -> Color.rgb(215, 25, 33)    // Nothing Red (#D71921)
                        cellHash < 175 -> Color.WHITE              // Pure White (#FFFFFF)
                        else -> Color.rgb(160, 160, 160)           // Technical Gray (#A0A0A0)
                    }

                    val dotAlpha = (energy * masterAlpha * 255f).toInt().coerceIn(0, 255)
                    val dotRadius = baseRadius + (maxPeakRadius - baseRadius) * energy

                    dotPaint.color = color
                    dotPaint.alpha = dotAlpha
                    canvas.drawCircle(x, y, dotRadius, dotPaint)
                }
            }
        }

        /**
         * Пресет 2: Glyph Pulse Ripple
         * Концентричні переривчасті дуги гліфів Nothing Phone + світіння та мікро-іскри.
         */
        private fun drawGlyphPulseRipple(
            canvas: Canvas,
            cx: Float,
            cy: Float
        ) {
            val scale = config.scale
            val p = progress.coerceIn(0f, 1.3f)
            val eased = 1f - (1f - min(p, 1f)) * (1f - min(p, 1f))

            // 1. Центральне кільце сканера (фіксований оптичний контур)
            val coreRingRadius = 38f * density * scale
            arcBounds.set(
                cx - coreRingRadius,
                cy - coreRingRadius,
                cx + coreRingRadius,
                cy + coreRingRadius
            )
            glyphGlowPaint.color = Color.rgb(215, 25, 33)
            glyphGlowPaint.strokeWidth = 10f * density * scale
            glyphGlowPaint.alpha = (95f * masterAlpha).toInt().coerceIn(0, 255)
            canvas.drawOval(arcBounds, glyphGlowPaint)

            glyphCorePaint.color = Color.WHITE
            glyphCorePaint.strokeWidth = 2.2f * density * scale
            glyphCorePaint.alpha = (230f * masterAlpha).toInt().coerceIn(0, 255)
            canvas.drawOval(arcBounds, glyphCorePaint)

            // 2. Три хвилі концентричних сегментів гліфів
            for (ringIdx in 0 until 3) {
                val ringDelay = ringIdx * 0.14f
                val localP = ((p - ringDelay) / (1f - ringDelay * 0.5f)).coerceIn(0f, 1.2f)
                if (localP <= 0f) continue

                val localEase = 1f - (1f - min(localP, 1f)) * (1f - min(localP, 1f))
                val radius = (46f + localEase * (145f + ringIdx * 48f)) * density * scale
                val ringAlpha = ((1f - localP * 0.72f) * masterAlpha).coerceIn(0f, 1f)
                if (ringAlpha <= 0.01f) continue

                arcBounds.set(cx - radius, cy - radius, cx + radius, cy + radius)

                val segmentCount = 4 + ringIdx
                val sweepAngle = (360f / segmentCount) * 0.62f
                val stepAngle = 360f / segmentCount
                val rotationOffset = (if (ringIdx % 2 == 0) 1f else -1f) * localEase * 28f

                for (seg in 0 until segmentCount) {
                    val startAngle = seg * stepAngle + rotationOffset
                    val isAccentSegment = (seg == 0 && ringIdx != 1) || (ringIdx == 2 && seg == 2)

                    val baseColor = if (isAccentSegment) {
                        Color.rgb(215, 25, 33) // Nothing Red
                    } else {
                        Color.WHITE
                    }

                    // М'яке зовнішнє світіння гліфа (Hardware-accelerated multi-stroke glow)
                    glyphGlowPaint.color = baseColor
                    glyphGlowPaint.strokeWidth = (11f - ringIdx * 2f) * density * scale
                    glyphGlowPaint.alpha = (ringAlpha * 68f).toInt().coerceIn(0, 255)
                    canvas.drawArc(arcBounds, startAngle, sweepAngle, false, glyphGlowPaint)

                    // Чітке ядро сегмента гліфа
                    glyphCorePaint.color = baseColor
                    glyphCorePaint.strokeWidth = (3.2f - ringIdx * 0.5f) * density * scale
                    glyphCorePaint.alpha = (ringAlpha * 245f).toInt().coerceIn(0, 255)
                    canvas.drawArc(arcBounds, startAngle, sweepAngle, false, glyphCorePaint)
                }
            }

            // 3. Мікро-іскри, що розлітаються по радіусу
            val maxSparkTravel = 195f * density * scale
            for (i in 0 until sparkCount) {
                val travel = (34f * density * scale) + eased * maxSparkTravel * sparkSpeedMult[i]
                val sx = cx + cos(sparkAngles[i]) * travel
                val sy = cy + sin(sparkAngles[i]) * travel
                val sparkAlpha = ((1f - eased * 0.85f) * masterAlpha * 255f).toInt().coerceIn(0, 255)

                sparkPaint.color = if (sparkIsRed[i]) Color.rgb(215, 25, 33) else Color.WHITE
                sparkPaint.alpha = sparkAlpha
                canvas.drawCircle(sx, sy, sparkSizes[i] * scale * (1f - eased * 0.35f), sparkPaint)
            }
        }

        /**
         * Пресет 3: Кастомний Lottie (.json) або прозорий .GIF
         */
        private fun drawCustomCanvasMedia(canvas: Canvas, cx: Float, cy: Float) {
            val targetHalfSize = 120f * density * config.scale
            val alphaInt = (masterAlpha * 255f).toInt().coerceIn(0, 255)

            when (config.customMediaType) {
                CustomMediaType.LOTTIE_JSON -> {
                    val drawable = lottieDrawable ?: return
                    val intrinsicW = drawable.intrinsicWidth.takeIf { it > 0 } ?: 300
                    val intrinsicH = drawable.intrinsicHeight.takeIf { it > 0 } ?: 300
                    val scaleFactor = (targetHalfSize * 2f) / max(intrinsicW, intrinsicH).toFloat()

                    drawable.alpha = alphaInt
                    drawable.setBounds(0, 0, intrinsicW, intrinsicH)
                    canvas.withTranslation(
                        cx - (intrinsicW * scaleFactor) / 2f,
                        cy - (intrinsicH * scaleFactor) / 2f
                    ) {
                        withScale(scaleFactor, scaleFactor) {
                            drawable.draw(this)
                        }
                    }
                }

                CustomMediaType.ANIMATED_GIF -> {
                    val drawable = gifDrawable ?: return
                    val intrinsicW = drawable.intrinsicWidth.takeIf { it > 0 } ?: 300
                    val intrinsicH = drawable.intrinsicHeight.takeIf { it > 0 } ?: 300
                    val scaleFactor = (targetHalfSize * 2f) / max(intrinsicW, intrinsicH).toFloat()

                    drawable.alpha = alphaInt
                    drawable.setBounds(0, 0, intrinsicW, intrinsicH)
                    canvas.withTranslation(
                        cx - (intrinsicW * scaleFactor) / 2f,
                        cy - (intrinsicH * scaleFactor) / 2f
                    ) {
                        withScale(scaleFactor, scaleFactor) {
                            drawable.draw(this)
                        }
                    }
                }

                else -> Unit
            }
        }
    }
}