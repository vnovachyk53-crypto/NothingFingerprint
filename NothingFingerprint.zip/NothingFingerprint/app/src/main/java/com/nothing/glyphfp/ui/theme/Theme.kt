package com.nothing.glyphfp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NothingBlack = Color(0xFF000000)
val NothingSurface = Color(0xFF141414)
val NothingSurfaceElevated = Color(0xFF1C1C1C)
val NothingBorder = Color(0xFF262626)
val NothingWhite = Color(0xFFFFFFFF)
val NothingGray = Color(0xFFA0A0A0)
val NothingMuted = Color(0xFF5E5E5E)
val NothingRed = Color(0xFFD71921)

private val NothingColorScheme = darkColorScheme(
    primary = NothingRed,
    onPrimary = NothingWhite,
    secondary = NothingWhite,
    onSecondary = NothingBlack,
    background = NothingBlack,
    onBackground = NothingWhite,
    surface = NothingSurface,
    onSurface = NothingWhite,
    surfaceVariant = NothingSurfaceElevated,
    onSurfaceVariant = NothingGray,
    outline = NothingBorder
)

@Composable
fun NothingGlyphTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NothingColorScheme,
        typography = NothingTypography,
        content = content
    )
}