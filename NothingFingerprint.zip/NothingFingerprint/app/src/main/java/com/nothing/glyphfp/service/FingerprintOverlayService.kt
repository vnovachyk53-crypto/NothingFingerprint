package com.nothing.glyphfp.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.nothing.glyphfp.data.SettingsRepository
import com.nothing.glyphfp.model.BiometricDialog
import com.nothing.glyphfp.model.ScannerConfig
import com.nothing.glyphfp.renderer.FingerprintAnimationView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.hypot

/**
 * Версія 1.2: жодного опитування вікон і жодного обходу дерев доступності.
 *
 * Екран блокування: ACTION_USER_PRESENT (головний тригер) і дотик (вікно-детектор 1x1 px та
 * TYPE_TOUCH_INTERACTION_START). Запит біометрії: лише TYPE_WINDOW_STATE_CHANGED.
 * У звичайних застосунках сервіс не виконує нічого, крім доставки цих подій.
 */
class FingerprintOverlayService : AccessibilityService() {

    private companion object {
        const val SYSTEM_UI_PACKAGE = "com.android.systemui"

        /** Дотик у AOD: чекаємо на пробудження екрана не довше цього часу. */
        const val PENDING_WAKE_MS = 1_500L

        /** Одноразовий запобіжник: маячок не лишається назавжди, якщо подію зникнення пропущено. */
        const val PROMPT_TIMEOUT_MS = 60_000L

        /** Одноразова перевірка після пробудження: стан блокування оновлюється з запізненням. */
        const val WAKE_RECHECK_MS = 400L
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var keyguardManager: KeyguardManager
    private lateinit var powerManager: PowerManager
    private lateinit var settingsRepository: SettingsRepository

    private var animationView: FingerprintAnimationView? = null
    private var touchWatcherView: View? = null
    private var beaconView: ScannerBeaconView? = null

    private var currentConfig = ScannerConfig()
    private var pendingTouchAt = 0L

    // Запит біометрії (банкінг): вікно SystemUI, що з'явилося над застосунком.
    private var promptWindowId = -1
    private var promptFired = false

    private var configJob: Job? = null
    private var testTriggerJob: Job? = null
    private var recheckJob: Job? = null
    private var promptTimeoutJob: Job? = null

    private val promptVisible: Boolean get() = promptWindowId != -1

    private val systemStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    animationView?.stopImmediately()
                    pendingTouchAt = 0L
                    endPrompt()
                    // Екран зараз заблокується: детектор дотику готується заздалегідь.
                    attachTouchWatcher()
                }

                Intent.ACTION_SCREEN_ON -> {
                    syncTouchWatcher()
                    if (SystemClock.elapsedRealtime() - pendingTouchAt < PENDING_WAKE_MS) {
                        pendingTouchAt = 0L
                        triggerAnimation()
                    }
                    recheckJob?.cancel()
                    recheckJob = serviceScope.launch {
                        delay(WAKE_RECHECK_MS)
                        syncTouchWatcher()
                    }
                }

                // Головний тригер: телефон розблоковано. Без таймерів і перевірок.
                Intent.ACTION_USER_PRESENT -> {
                    pendingTouchAt = 0L
                    triggerAnimation()
                    endPrompt()
                    syncTouchWatcher()
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        keyguardManager = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        powerManager = getSystemService(POWER_SERVICE) as PowerManager
        settingsRepository = SettingsRepository(applicationContext)

        attachFullScreenOverlay()
        registerSystemReceivers()
        observeSettingsAndTestEvents()
        syncTouchWatcher()

        ServiceStateBus.setServiceRunning(true)
    }

    private fun overlayParams(width: Int, height: Int, flags: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Вікна рахуються від краю фізичного екрана, як і приціл калібрування.
            fitInsetsTypes = 0
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
    }

    private fun passThroughFlags(): Int {
        return WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    private fun attachFullScreenOverlay() {
        if (animationView != null) return

        val view = FingerprintAnimationView(this)
        val params = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            passThroughFlags()
        )
        params.title = "NothingGlyphFingerprintOverlay"

        runCatching {
            windowManager.addView(view, params)
            animationView = view
        }
    }

    /** Детектор дотику існує лише на екрані блокування або під час запиту біометрії. */
    private fun syncTouchWatcher() {
        if (keyguardManager.isKeyguardLocked || promptVisible) {
            attachTouchWatcher()
        } else {
            detachTouchWatcher()
        }
    }

    /**
     * Вікно 1x1 px нічого не перехоплює і отримує лише ACTION_OUTSIDE. Координати чужих дотиків
     * Android приховує, тому реагуємо на дотик у будь-якому місці.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouchWatcher() {
        if (touchWatcherView != null) return

        val watcher = View(this)
        watcher.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) onTouch(event.rawX, event.rawY)
            false
        }
        val params = overlayParams(
            1,
            1,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        runCatching {
            windowManager.addView(watcher, params)
            touchWatcherView = watcher
        }
    }

    private fun detachTouchWatcher() {
        val watcher = touchWatcherView ?: return
        touchWatcherView = null
        runCatching { windowManager.removeViewImmediate(watcher) }
    }

    /** Дотик з вікна-детектора або з TYPE_TOUCH_INTERACTION_START. */
    private fun onTouch(rawX: Float, rawY: Float) {
        // Поза блокуванням і запитом біометрії детектора немає: подія виходить одразу.
        if (touchWatcherView == null) return

        if (keyguardManager.isKeyguardLocked) {
            // Блокування: будь-який дотик, пакет вікна не перевіряється.
            if (powerManager.isInteractive) {
                triggerAnimation()
            } else {
                pendingTouchAt = SystemClock.elapsedRealtime()
            }
            return
        }

        if (!promptVisible) {
            syncTouchWatcher()
            return
        }
        if (!promptWindowExists()) {
            // Запит зник, а подію зникнення не отримано.
            val fire = !promptFired
            endPrompt()
            if (fire) triggerAnimation()
            return
        }
        val coordinatesHidden = rawX == 0f && rawY == 0f
        if (coordinatesHidden || isTouchInScannerZone(rawX, rawY)) triggerAnimation()
    }

    /** Одноразовий пошук вікна за id (без обходу дерева вузлів). */
    private fun promptWindowExists(): Boolean {
        val list = runCatching { windows }.getOrNull() ?: return true
        return list.any { it.id == promptWindowId }
    }

    private fun showBeacon() {
        if (beaconView != null) return

        val density = resources.displayMetrics.density
        val radius = currentConfig.scannerRadiusDp * density
        val half = (radius + 8f * density).toInt()
        val (sensorX, sensorY) = sensorPosition()

        val beacon = ScannerBeaconView(this, radius)
        val params = overlayParams(half * 2, half * 2, passThroughFlags())
        params.x = sensorX.toInt() - half
        params.y = sensorY.toInt() - half

        runCatching {
            windowManager.addView(beacon, params)
            beaconView = beacon
        }
    }

    private fun hideBeacon() {
        val beacon = beaconView ?: return
        beaconView = null
        runCatching { windowManager.removeViewImmediate(beacon) }
    }

    private fun sensorPosition(): Pair<Float, Float> {
        val bounds = windowManager.maximumWindowMetrics.bounds
        return Pair(
            bounds.width() * currentConfig.centerXNormalized,
            bounds.height() * currentConfig.centerYNormalized
        )
    }

    private fun isTouchInScannerZone(rawX: Float, rawY: Float): Boolean {
        val (sensorX, sensorY) = sensorPosition()
        val radius = currentConfig.scannerRadiusDp * resources.displayMetrics.density
        return hypot(rawX - sensorX, rawY - sensorY) <= radius
    }

    /**
     * Анімація, що вже грає, не перезапускається: після дотику вона просто дограє,
     * навіть якщо слідом прийшов ACTION_USER_PRESENT.
     */
    private fun triggerAnimation() {
        val view = animationView ?: return
        if (view.isAnimating) return
        promptFired = true
        view.triggerAnimation()
        if (currentConfig.hapticEnabled) Haptics.click(this)
        hideBeacon()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindowStateChanged(event)
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START -> onTouch(0f, 0f)
        }
    }

    /**
     * Запит біометрії над застосунком. Лише подія зміни стану вікна, без опитування.
     * Екран блокування обробляється окремо, тому тут його пропускаємо.
     */
    private fun onWindowStateChanged(event: AccessibilityEvent) {
        if (keyguardManager.isKeyguardLocked) return
        val fromSystemUi = event.packageName?.toString() == SYSTEM_UI_PACKAGE

        if (fromSystemUi) {
            if (promptVisible || !powerManager.isInteractive) return
            if (isBiometricDialog(event)) beginPrompt(event.windowId)
        } else if (promptVisible && !promptWindowExists()) {
            // Подія застосунку, а вікна біометрії вже немає: воно зникло.
            val fire = !promptFired
            endPrompt()
            if (fire) triggerAnimation()
        }
    }

    private fun isBiometricDialog(event: AccessibilityEvent): Boolean {
        val metrics = resources.displayMetrics
        val bounds = Rect()
        runCatching { windows }.getOrNull()
            ?.firstOrNull { it.id == event.windowId }
            ?.getBoundsInScreen(bounds)
        return BiometricDialog.isPrompt(
            className = event.className?.toString(),
            width = bounds.width(),
            height = bounds.height(),
            displayWidth = metrics.widthPixels,
            displayHeight = metrics.heightPixels
        )
    }

    private fun beginPrompt(windowId: Int) {
        promptWindowId = windowId
        promptFired = false
        attachTouchWatcher()
        if (currentConfig.beaconEnabled) showBeacon()
        promptTimeoutJob?.cancel()
        promptTimeoutJob = serviceScope.launch {
            delay(PROMPT_TIMEOUT_MS)
            endPrompt()
        }
    }

    private fun endPrompt() {
        promptWindowId = -1
        promptFired = false
        promptTimeoutJob?.cancel()
        promptTimeoutJob = null
        hideBeacon()
        if (!keyguardManager.isKeyguardLocked && powerManager.isInteractive) detachTouchWatcher()
    }

    private fun observeSettingsAndTestEvents() {
        configJob?.cancel()
        configJob = serviceScope.launch {
            settingsRepository.configFlow.collectLatest { config: ScannerConfig ->
                val beaconMoved = config.scannerRadiusDp != currentConfig.scannerRadiusDp ||
                        config.centerXNormalized != currentConfig.centerXNormalized ||
                        config.centerYNormalized != currentConfig.centerYNormalized ||
                        !config.beaconEnabled
                currentConfig = config
                animationView?.updateConfig(config)
                if (beaconMoved) {
                    hideBeacon()
                    if (promptVisible && config.beaconEnabled) showBeacon()
                }
            }
        }

        testTriggerJob?.cancel()
        testTriggerJob = serviceScope.launch {
            ServiceStateBus.testTriggerEvents.collectLatest { triggerAnimation() }
        }
    }

    private fun registerSystemReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemStateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(systemStateReceiver, filter)
        }
    }

    override fun onInterrupt() {
        animationView?.stopImmediately()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanupResources()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanupResources()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun cleanupResources() {
        ServiceStateBus.setServiceRunning(false)
        listOf(configJob, testTriggerJob, recheckJob, promptTimeoutJob).forEach { it?.cancel() }
        configJob = null
        testTriggerJob = null
        recheckJob = null
        promptTimeoutJob = null
        promptWindowId = -1
        runCatching { unregisterReceiver(systemStateReceiver) }
        detachTouchWatcher()
        hideBeacon()
        animationView?.let { view ->
            runCatching {
                view.stopImmediately()
                windowManager.removeViewImmediate(view)
            }
        }
        animationView = null
    }
}
