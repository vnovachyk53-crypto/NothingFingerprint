package com.nothing.glyphfp.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.nothing.glyphfp.data.SettingsRepository
import com.nothing.glyphfp.model.DwellFilter
import com.nothing.glyphfp.model.RecentEvent
import com.nothing.glyphfp.model.ScannerConfig
import com.nothing.glyphfp.model.TriggerMode
import com.nothing.glyphfp.model.TriggerPolicy
import com.nothing.glyphfp.model.TriggerState
import com.nothing.glyphfp.model.UiSnapshot
import com.nothing.glyphfp.renderer.FingerprintAnimationView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

class FingerprintOverlayService : AccessibilityService() {

    private companion object {
        const val SYSTEM_UI_PACKAGE = "com.android.systemui"
        const val DEBOUNCE_MS = 100L
        const val PENDING_TRIGGER_MS = 1_500L
        const val SCAN_INTERVAL_MS = 120L
        const val RESCAN_MS = 800L
        const val WAKE_RECHECK_MS = 350L
        const val SWIPE_CANCEL_MS = 900L
        const val SWIPE_CONFIRM_SCANS = 2
        const val BEACON_PAUSE_MS = 2_000L

        /** Розблокування пальцем швидше за подію дотику: ACTION_USER_PRESENT дає запуск. */
        const val UNLOCK_INSURANCE_MS = 3_500L

        /** Застосунок поверх блокування (камера, дзвінок) вимикає детектор після цього часу. */
        const val OCCLUSION_CONFIRM_MS = 1_000L

        /** Діалоги, що відкриваються одразу після шторки, не вважаються запитом біометрії. */
        const val SHADE_RECENT_MS = 1_500L
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val scanRequests = Channel<Unit>(Channel.CONFLATED)
    private lateinit var windowManager: WindowManager
    private lateinit var keyguardManager: KeyguardManager
    private lateinit var powerManager: PowerManager
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var scanner: SystemUiScanner

    private var animationView: FingerprintAnimationView? = null
    private var touchWatcherView: View? = null
    private var beaconView: ScannerBeaconView? = null

    private var currentConfig = ScannerConfig()
    private var ui = UiSnapshot()
    private var isBeaconPaused = false
    private var lastTriggerAt = 0L
    private var lastTouchTriggerAt = 0L
    private var pendingTriggerAt = 0L
    private var lastWakeAt = 0L
    private var firedThisLockSession = false
    private var credentialSeenThisSession = false
    private var swipeEvidenceScans = 0
    private val occlusionFilter = DwellFilter(OCCLUSION_CONFIRM_MS)
    private val recentShade = RecentEvent(SHADE_RECENT_MS)

    private var configJob: Job? = null
    private var testTriggerJob: Job? = null
    private var scanJob: Job? = null
    private var rescanJob: Job? = null
    private var wakeJob: Job? = null
    private var beaconJob: Job? = null

    private val systemStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Повна зупинка рендеру при вимкненому екрані для економії заряду
                    animationView?.stopImmediately()
                    ui = UiSnapshot()
                    // Усі прапорці скидаються одразу: наступне розблокування стартує з першого разу.
                    resetTriggerState()
                    wakeJob?.cancel()
                    // Детектор для екрана блокування готується заздалегідь.
                    applyState()
                }

                Intent.ACTION_SCREEN_ON -> {
                    ui = UiSnapshot()
                    lastWakeAt = SystemClock.elapsedRealtime()
                    occlusionFilter.reset()
                    applyState()
                    requestScan()
                    if (SystemClock.elapsedRealtime() - pendingTriggerAt < PENDING_TRIGGER_MS) {
                        pendingTriggerAt = 0L
                        triggerAnimation(fromTouch = false)
                    }
                    // Стан блокування може оновитися трохи пізніше за пробудження.
                    wakeJob?.cancel()
                    wakeJob = serviceScope.launch {
                        delay(WAKE_RECHECK_MS)
                        applyState()
                        requestScan()
                    }
                }

                Intent.ACTION_USER_PRESENT -> {
                    ui = UiSnapshot()
                    onUserPresent()
                    applyState()
                    requestScan()
                }
            }
        }
    }

    /**
     * Телефон розблоковано. У режимі "Після розблокування" це основний запуск. У режимі "На дотик"
     * це страховка: якщо палець розблокував телефон швидше, ніж прийшла подія дотику, анімація
     * все одно стартує. Розблокування PIN/паролем не підходить: воно довше за
     * [UNLOCK_INSURANCE_MS] від пробудження або супроводжується видимим введенням.
     */
    private fun onUserPresent() {
        val now = SystemClock.elapsedRealtime()
        when (currentConfig.triggerMode) {
            TriggerMode.AFTER_UNLOCK -> triggerAnimation(fromTouch = false)
            TriggerMode.BIOMETRIC_TOUCH -> {
                val fastUnlock = lastWakeAt != 0L && now - lastWakeAt < UNLOCK_INSURANCE_MS
                if (!firedThisLockSession && !credentialSeenThisSession && fastUnlock) {
                    triggerAnimation(fromTouch = false)
                }
            }
        }
        // Наступний сеанс блокування починається з чистого стану.
        firedThisLockSession = false
        credentialSeenThisSession = false
        occlusionFilter.reset()
    }

    /** Скидає все, що могло б затримати або заблокувати наступний запуск. */
    private fun resetTriggerState() {
        lastTriggerAt = 0L
        lastTouchTriggerAt = 0L
        pendingTriggerAt = 0L
        firedThisLockSession = false
        credentialSeenThisSession = false
        swipeEvidenceScans = 0
        isBeaconPaused = false
        beaconJob?.cancel()
        beaconJob = null
        occlusionFilter.reset()
        recentShade.clear()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        keyguardManager = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        powerManager = getSystemService(POWER_SERVICE) as PowerManager
        settingsRepository = SettingsRepository(applicationContext)
        scanner = SystemUiScanner(this)

        attachFullScreenOverlay()
        registerSystemReceivers()
        startScanLoop()
        observeSettingsAndTestEvents()

        ServiceStateBus.setServiceRunning(true)
        applyState()
        requestScan()
    }

    private fun overlayParams(width: Int, height: Int, flags: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Вікна рахуються від краю фізичного екрана, як і приціл калібрування.
            fitInsetsTypes = 0
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
    }

    private fun passThroughFlags(): Int {
        return WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    private fun attachFullScreenOverlay() {
        if (animationView != null) return

        val view = FingerprintAnimationView(this)
        val params = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            passThroughFlags()
        )
        params.title = "NothingGlyphFingerprintOverlay"

        runCatching {
            windowManager.addView(view, params)
            animationView = view
        }
    }

    /** Приводить детектор дотику та маячок у відповідність до поточного стану екрана. */
    private fun applyState() {
        val interactive = powerManager.isInteractive
        val locked = keyguardManager.isKeyguardLocked
        val state = evaluateState(interactive, locked)

        if (state.watchTouch) attachTouchWatcher() else detachTouchWatcher()
        if (state.showBeacon && !isBeaconPaused) showBeacon() else hideBeacon()
        updateRescanLoop(interactive && (locked || ui.biometricPrompt))
    }

    private fun evaluateState(interactive: Boolean, locked: Boolean): TriggerState {
        return TriggerPolicy.evaluate(
            interactive = interactive,
            keyguardLocked = locked,
            mode = currentConfig.triggerMode,
            beaconEnabled = currentConfig.beaconEnabled,
            ui = ui
        )
    }

    /**
     * Вікно 1x1 px нічого не перехоплює і отримує лише ACTION_OUTSIDE. Воно існує тільки на
     * екрані блокування або під час запиту біометрії. Координати чужих дотиків Android
     * зазвичай приховує, тоді анімація стартує в точці прицілу.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouchWatcher() {
        if (touchWatcherView != null) return

        val watcher = View(this)
        watcher.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                onOutsideTouch(event.rawX, event.rawY)
            }
            false
        }
        val params = overlayParams(
            1,
            1,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        runCatching {
            windowManager.addView(watcher, params)
            touchWatcherView = watcher
        }
    }

    private fun detachTouchWatcher() {
        val watcher = touchWatcherView ?: return
        touchWatcherView = null
        runCatching { windowManager.removeViewImmediate(watcher) }
    }

    private fun onOutsideTouch(rawX: Float, rawY: Float) {
        // Стан перевіряється ще раз у момент дотику, щоб застаріле вікно нічого не запустило.
        val interactive = powerManager.isInteractive
        val locked = keyguardManager.isKeyguardLocked
        val state = evaluateState(interactive, locked)
        if (!state.watchTouch) {
            applyState()
            return
        }
        // На екрані блокування (включно з AOD і пробудженням) спрацьовує будь-який дотик.
        val onLockscreen = locked && !ui.appOverLockscreen
        val coordinatesHidden = rawX == 0f && rawY == 0f
        if (onLockscreen || coordinatesHidden || isTouchInScannerZone(rawX, rawY)) {
            triggerAnimation(fromTouch = true)
        }
        requestScan()
    }

    private fun showBeacon() {
        if (beaconView != null) return

        val density = resources.displayMetrics.density
        val radius = currentConfig.scannerRadiusDp * density
        val half = (radius + 8f * density).toInt()
        val (sensorX, sensorY) = sensorPosition()

        val beacon = ScannerBeaconView(this, radius)
        val params = overlayParams(half * 2, half * 2, passThroughFlags())
        params.x = sensorX.toInt() - half
        params.y = sensorY.toInt() - half

        runCatching {
            windowManager.addView(beacon, params)
            beaconView = beacon
        }
    }

    private fun hideBeacon() {
        val beacon = beaconView ?: return
        beaconView = null
        runCatching { windowManager.removeViewImmediate(beacon) }
    }

    private fun sensorPosition(): Pair<Float, Float> {
        val bounds = windowManager.maximumWindowMetrics.bounds
        return Pair(
            bounds.width() * currentConfig.centerXNormalized,
            bounds.height() * currentConfig.centerYNormalized
        )
    }

    private fun isTouchInScannerZone(rawX: Float, rawY: Float): Boolean {
        val (sensorX, sensorY) = sensorPosition()
        val radius = currentConfig.scannerRadiusDp * resources.displayMetrics.density
        return hypot(rawX - sensorX, rawY - sensorY) <= radius
    }

    private fun triggerAnimation(fromTouch: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!powerManager.isInteractive) {
            // Екран ще прокидається: запустимо анімацію після ACTION_SCREEN_ON.
            pendingTriggerAt = now
            lastWakeAt = now
            return
        }
        if (now - lastTriggerAt < DEBOUNCE_MS) return
        lastTriggerAt = now
        firedThisLockSession = true
        if (fromTouch) lastTouchTriggerAt = now

        animationView?.triggerAnimation()
        if (currentConfig.hapticEnabled) Haptics.click(this)
        pauseBeacon()
    }

    /** Поки грає анімація, маячок прихований. */
    private fun pauseBeacon() {
        isBeaconPaused = true
        hideBeacon()
        beaconJob?.cancel()
        beaconJob = serviceScope.launch {
            delay(BEACON_PAUSE_MS)
            isBeaconPaused = false
            applyState()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                applyState()
                requestScan()
            }

            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                if (event.packageName?.toString() == SYSTEM_UI_PACKAGE) requestScan()
            }

            // Додаткове джерело початку дотику (доставляється не на всіх прошивках).
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START -> onOutsideTouch(0f, 0f)
        }
    }

    private fun requestScan() {
        scanRequests.trySend(Unit)
    }

    /** Запити об'єднуються; вікна читаються у фоновому потоці, щоб не гальмувати анімацію. */
    private fun startScanLoop() {
        scanJob?.cancel()
        scanJob = serviceScope.launch {
            for (request in scanRequests) {
                if (powerManager.isInteractive) {
                    val locked = keyguardManager.isKeyguardLocked
                    val shadeRecent = recentShade.isRecent(SystemClock.elapsedRealtime())
                    val result = withContext(Dispatchers.Default) {
                        scanner.scan(locked, shadeRecent)
                    }
                    if (powerManager.isInteractive) onScanResult(result)
                }
                delay(SCAN_INTERVAL_MS)
            }
        }
    }

    private fun onScanResult(result: SystemUiScanner.Result) {
        val now = SystemClock.elapsedRealtime()
        val locked = keyguardManager.isKeyguardLocked
        val promptWasVisible = ui.biometricPrompt
        val raw = result.ui

        if (raw.shadeExpanded) recentShade.mark(now)
        if (locked && raw.credentialInput) credentialSeenThisSession = true
        // Застосунок поверх блокування враховується лише після короткого підтвердження.
        val occluded = occlusionFilter.update(locked && raw.appOverLockscreen, now)
        ui = raw.copy(appOverLockscreen = occluded)

        // Біометричне вікно зникло: скидаємо стан негайно, без очікування таймерів.
        if (promptWasVisible && !ui.biometricPrompt) resetTriggerState()

        // Дотик виявився початком свайпу шторки або введення PIN: скасовуємо анімацію,
        // але лише коли ознаку підтверджено кількома скануваннями поспіль.
        val recentTouch = now - lastTouchTriggerAt < SWIPE_CANCEL_MS
        // Лише на заблокованому екрані, щоб перехід після розблокування не обривав анімацію.
        val swipedAway = ui.shadeExpanded || ui.credentialInput
        if (recentTouch && swipedAway && locked) {
            swipeEvidenceScans++
            if (swipeEvidenceScans >= SWIPE_CONFIRM_SCANS) {
                animationView?.stopImmediately()
                swipeEvidenceScans = 0
            }
        } else {
            swipeEvidenceScans = 0
        }

        if (locked) {
            ServiceStateBus.reportLockscreen(
                if (ui.appOverLockscreen) "застосунок поверх блокування" else null
            )
        } else {
            if (ui.biometricPrompt) {
                ServiceStateBus.reportBiometricPrompt(result.promptByOverlay)
            } else if (result.unknownIds.isNotEmpty()) {
                ServiceStateBus.reportUnknownWindow(result.unknownIds)
            }
        }
        applyState()
    }

    /** Страховка на випадок пропущеної події, поки видно блокування або запит біометрії. */
    private fun updateRescanLoop(needed: Boolean) {
        if (!needed) {
            rescanJob?.cancel()
            rescanJob = null
        } else if (rescanJob == null) {
            rescanJob = serviceScope.launch {
                while (true) {
                    delay(RESCAN_MS)
                    requestScan()
                }
            }
        }
    }

    private fun observeSettingsAndTestEvents() {
        configJob?.cancel()
        configJob = serviceScope.launch {
            settingsRepository.configFlow.collectLatest { config: ScannerConfig ->
                val beaconMoved = config.scannerRadiusDp != currentConfig.scannerRadiusDp ||
                        config.centerXNormalized != currentConfig.centerXNormalized ||
                        config.centerYNormalized != currentConfig.centerYNormalized
                currentConfig = config
                animationView?.updateConfig(config)
                if (beaconMoved) hideBeacon()
                applyState()
            }
        }

        testTriggerJob?.cancel()
        testTriggerJob = serviceScope.launch {
            ServiceStateBus.testTriggerEvents.collectLatest {
                triggerAnimation(fromTouch = false)
            }
        }
    }

    private fun registerSystemReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemStateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(systemStateReceiver, filter)
        }
    }

    override fun onInterrupt() {
        animationView?.stopImmediately()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanupResources()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanupResources()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun cleanupResources() {
        ServiceStateBus.setServiceRunning(false)
        listOf(configJob, testTriggerJob, scanJob, rescanJob, wakeJob, beaconJob)
            .forEach { it?.cancel() }
        configJob = null
        testTriggerJob = null
        scanJob = null
        rescanJob = null
        wakeJob = null
        beaconJob = null
        resetTriggerState()
        ui = UiSnapshot()
        runCatching { unregisterReceiver(systemStateReceiver) }
        detachTouchWatcher()
        hideBeacon()
        animationView?.let { view ->
            runCatching {
                view.stopImmediately()
                windowManager.removeViewImmediate(view)
            }
        }
        animationView = null
    }
}
