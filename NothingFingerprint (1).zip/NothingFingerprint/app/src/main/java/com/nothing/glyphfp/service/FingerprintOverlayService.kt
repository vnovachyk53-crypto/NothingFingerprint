package com.nothing.glyphfp.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.nothing.glyphfp.data.SettingsRepository
import com.nothing.glyphfp.model.SCANNER_ZONE_RADIUS_DP
import com.nothing.glyphfp.model.ScannerConfig
import com.nothing.glyphfp.renderer.FingerprintAnimationView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.hypot

class FingerprintOverlayService : AccessibilityService() {

    private companion object {
        const val BIOMETRIC_TIMEOUT_MS = 15_000L
        const val DEBOUNCE_MS = 100L
        const val PENDING_TRIGGER_MS = 700L
        const val SCAN_INTERVAL_MS = 250L
        const val MAX_ZONE_TOUCHES = 3
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var keyguardManager: KeyguardManager
    private lateinit var powerManager: PowerManager
    private lateinit var settingsRepository: SettingsRepository

    private var animationView: FingerprintAnimationView? = null
    private var touchProbeView: View? = null

    private var isOverlayAttached = false
    private var isTouchProbeAttached = false
    private var isBiometricDialogVisible = false
    private var currentConfig = ScannerConfig()
    private var lastTriggerTimestamp = 0L
    private var pendingTriggerTimestamp = 0L
    private var lastScanTimestamp = 0L
    private var zoneTouchCount = 0

    private var configJob: Job? = null
    private var testTriggerJob: Job? = null
    private var biometricTimeoutJob: Job? = null

    private val systemStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Повна зупинка рендеру при вимкненому екрані для економії заряду
                    animationView?.stopImmediately()
                    isBiometricDialogVisible = false
                    zoneTouchCount = 0
                    // Детектор готуємо заздалегідь, щоб перший дотик після пробудження не губився.
                    updateTouchProbeState()
                }

                Intent.ACTION_SCREEN_ON -> {
                    updateTouchProbeState()
                    if (System.currentTimeMillis() - pendingTriggerTimestamp < PENDING_TRIGGER_MS) {
                        pendingTriggerTimestamp = 0L
                        animationView?.triggerAnimation()
                    }
                }

                Intent.ACTION_USER_PRESENT -> {
                    // Анімацію не обриваємо: при швидкому розпізнаванні вона має догратися.
                    isBiometricDialogVisible = false
                    zoneTouchCount = 0
                    detachTouchProbe()
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        keyguardManager = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        powerManager = getSystemService(POWER_SERVICE) as PowerManager
        settingsRepository = SettingsRepository(applicationContext)

        attachFullScreenOverlay()
        registerSystemReceivers()
        observeSettingsAndTestEvents()

        ServiceStateBus.setServiceRunning(true)
        updateTouchProbeState()
    }

    private fun attachFullScreenOverlay() {
        if (isOverlayAttached) return

        val view = FingerprintAnimationView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Вікно на весь фізичний екран: координати збігаються з прицілом калібрування.
            fitInsetsTypes = 0
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            title = "NothingGlyphFingerprintOverlay"
        }

        runCatching {
            windowManager.addView(view, params)
            animationView = view
            isOverlayAttached = true
        }
    }

    /**
     * Звичайний режим: вікно 1x1 px отримує ACTION_OUTSIDE і не перехоплює дотики, але Android
     * зазвичай не повідомляє координати чужих дотиків.
     *
     * Сувора зона: вікно в точці сканера отримує справжні координати, проте ЗАБИРАЄ дотики в
     * цій зоні, тому сканер відбитків або клавіші PIN під ним можуть їх не отримати.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouchProbe() {
        if (isTouchProbeAttached) return

        val strict = currentConfig.strictZone
        val radius = SCANNER_ZONE_RADIUS_DP * resources.displayMetrics.density
        val size = if (strict) (radius * 2f).toInt() else 1
        val (sensorX, sensorY) = sensorPosition()

        val probe = View(this).apply {
            setOnTouchListener { _, event ->
                if (strict) {
                    if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                        onZoneTouched(event.rawX, event.rawY)
                    }
                    true
                } else {
                    if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                        val coordinatesHidden = event.rawX == 0f && event.rawY == 0f
                        if (coordinatesHidden || isTouchInScannerZone(event.rawX, event.rawY)) {
                            onScannerInteractionDetected()
                        }
                    }
                    false
                }
            }
        }

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!strict) {
            flags = flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        }

        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            fitInsetsTypes = 0
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            x = if (strict) (sensorX - radius).toInt() else 0
            y = if (strict) (sensorY - radius).toInt() else 0
        }

        runCatching {
            windowManager.addView(probe, params)
            touchProbeView = probe
            isTouchProbeAttached = true
        }
    }

    private fun detachTouchProbe() {
        if (!isTouchProbeAttached) return
        runCatching {
            touchProbeView?.let { windowManager.removeViewImmediate(it) }
        }
        touchProbeView = null
        isTouchProbeAttached = false
    }

    private fun updateTouchProbeState() {
        val needed = !powerManager.isInteractive ||
                keyguardManager.isKeyguardLocked ||
                isBiometricDialogVisible
        // Запобіжник суворої зони: після кількох дотиків звільняємо її до вимкнення екрана.
        val suspended = currentConfig.strictZone && zoneTouchCount >= MAX_ZONE_TOUCHES
        if (needed && !suspended) {
            attachTouchProbe()
        } else {
            detachTouchProbe()
        }
    }

    private fun onZoneTouched(rawX: Float, rawY: Float) {
        zoneTouchCount++
        if (isTouchInScannerZone(rawX, rawY)) {
            onScannerInteractionDetected()
        }
        if (zoneTouchCount >= MAX_ZONE_TOUCHES) {
            // Вікно не можна видаляти зсередини його власного обробника дотику.
            serviceScope.launch {
                delay(DEBOUNCE_MS)
                updateTouchProbeState()
            }
        }
    }

    private fun sensorPosition(): Pair<Float, Float> {
        val bounds = windowManager.maximumWindowMetrics.bounds
        return Pair(
            bounds.width() * currentConfig.centerXNormalized,
            bounds.height() * currentConfig.centerYNormalized
        )
    }

    private fun isTouchInScannerZone(rawX: Float, rawY: Float): Boolean {
        val (sensorX, sensorY) = sensorPosition()
        val radius = SCANNER_ZONE_RADIUS_DP * resources.displayMetrics.density
        return hypot(rawX - sensorX, rawY - sensorY) <= radius
    }

    private fun onScannerInteractionDetected() {
        val now = System.currentTimeMillis()
        if (!powerManager.isInteractive) {
            // Екран ще прокидається: запустимо анімацію після ACTION_SCREEN_ON.
            pendingTriggerTimestamp = now
            return
        }
        if (now - lastTriggerTimestamp < DEBOUNCE_MS) return
        lastTriggerTimestamp = now
        animationView?.triggerAnimation()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString().orEmpty()
        if (pkg == packageName) return

        // На заблокованому екрані детектор потрібен завжди, тож дерево вікон не обходимо:
        // ці повільні запити виконуються в тому ж потоці, що й анімація.
        if (keyguardManager.isKeyguardLocked) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                updateTouchProbeState()
            }
            return
        }

        // Відстежуємо появу системного BiometricPrompt
        if (pkg == "com.android.systemui" || pkg.contains("biometric")) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                val now = System.currentTimeMillis()
                if (now - lastScanTimestamp < SCAN_INTERVAL_MS) return
                lastScanTimestamp = now
            }
            val sourceNode = event.source
            val hasBiometricNode = try {
                checkBiometricOrUdfpsNode(sourceNode)
            } finally {
                sourceNode?.recycle()
            }
            val hasBiometricUi = hasBiometricNode || event.text.any { text ->
                val value = text.toString().lowercase()
                value.contains("fingerprint") || value.contains("відбит") || value.contains("biometric")
            }

            if (hasBiometricUi) {
                isBiometricDialogVisible = true
                scheduleBiometricTimeout()
                updateTouchProbeState()
            } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                updateTouchProbeState()
            }
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            // Відкрилося вікно іншого застосунку: біометричний діалог більше не активний.
            isBiometricDialogVisible = false
            updateTouchProbeState()
        }
    }

    /** Не дає детектору дотику лишитися ввімкненим, якщо закриття діалогу не дало події. */
    private fun scheduleBiometricTimeout() {
        biometricTimeoutJob?.cancel()
        biometricTimeoutJob = serviceScope.launch {
            delay(BIOMETRIC_TIMEOUT_MS)
            isBiometricDialogVisible = false
            zoneTouchCount = 0
            updateTouchProbeState()
        }
    }

    private fun checkBiometricOrUdfpsNode(root: AccessibilityNodeInfo?): Boolean {
        root ?: return false
        var inspectedNodes = 0

        fun containsScannerNode(node: AccessibilityNodeInfo, depth: Int): Boolean {
            if (++inspectedNodes > 80) return false

            val viewId = node.viewIdResourceName?.lowercase().orEmpty()
            val label = listOfNotNull(
                node.text?.toString(),
                node.contentDescription?.toString()
            ).joinToString(" ").lowercase()

            val isScannerNode = viewId.contains("udfps") ||
                    viewId.contains("biometric") ||
                    viewId.contains("fingerprint") ||
                    viewId.contains("lock_icon") ||
                    label.contains("fingerprint") ||
                    label.contains("biometric") ||
                    label.contains("відбит")

            if (isScannerNode) return true
            if (depth >= 6) return false

            val childCount = node.childCount.coerceAtMost(12)
            for (index in 0 until childCount) {
                val child = node.getChild(index) ?: continue
                val found = try {
                    containsScannerNode(child, depth + 1)
                } finally {
                    child.recycle()
                }
                if (found) return true
            }
            return false
        }

        return containsScannerNode(root, depth = 0)
    }

    private fun observeSettingsAndTestEvents() {
        configJob?.cancel()
        configJob = serviceScope.launch {
            settingsRepository.configFlow.collectLatest { config: ScannerConfig ->
                val zoneChanged = config.strictZone != currentConfig.strictZone ||
                        config.centerXNormalized != currentConfig.centerXNormalized ||
                        config.centerYNormalized != currentConfig.centerYNormalized
                currentConfig = config
                animationView?.updateConfig(config)
                if (zoneChanged) {
                    zoneTouchCount = 0
                    detachTouchProbe()
                    updateTouchProbeState()
                }
            }
        }

        testTriggerJob?.cancel()
        testTriggerJob = serviceScope.launch {
            ServiceStateBus.testTriggerEvents.collectLatest {
                animationView?.triggerAnimation()
            }
        }
    }

    private fun registerSystemReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemStateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(systemStateReceiver, filter)
        }
    }

    override fun onInterrupt() {
        animationView?.stopImmediately()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanupResources()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanupResources()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun cleanupResources() {
        ServiceStateBus.setServiceRunning(false)
        configJob?.cancel()
        configJob = null
        testTriggerJob?.cancel()
        testTriggerJob = null
        biometricTimeoutJob?.cancel()
        biometricTimeoutJob = null
        isBiometricDialogVisible = false
        runCatching { unregisterReceiver(systemStateReceiver) }
        detachTouchProbe()
        if (isOverlayAttached) {
            runCatching {
                animationView?.stopImmediately()
                animationView?.let { windowManager.removeViewImmediate(it) }
            }
            animationView = null
            isOverlayAttached = false
        }
    }
}